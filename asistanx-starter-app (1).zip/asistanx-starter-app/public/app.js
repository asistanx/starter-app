/*
 * AsistanX Starter App — tarayıcı tarafı.
 *
 * 1) Oturum anahtarını adres çubuğundan alır, bellekte tutar ve adresten siler.
 * 2) AsistanX paneliyle (üst pencere) postMessage köprüsü kurar; panel, anahtarın süresi
 *    dolmadan yenisini yollar. Yalnız anahtarı imzalanmış panel adresinden gelen mesajlar
 *    kabul edilir.
 * 3) Kendi sunucusuna her istekte anahtarı "Authorization: Bearer" başlığıyla gönderir
 *    (iframe içinde çerez güvenilir değildir).
 */
(function () {
  'use strict';

  const parentOrigin = document.body.dataset.parentOrigin;
  const params = new URLSearchParams(window.location.search);
  let token = params.get('token');
  /* Adres eşitleme: panel adresindeki uygulama içi yol (ör. "/notlar"). Panel yenilenince buradan gelir. */
  const startPath = params.get('path') || '';
  let expiresAt = 0;
  let nextRequestId = 1;
  const waiting = new Map();

  /* Anahtar adres çubuğunda ve tarayıcı geçmişinde kalmasın. */
  window.history.replaceState(null, '', window.location.pathname);

  const inFrame = window.parent !== window;

  function toParent(message) {
    if (inFrame && parentOrigin) {
      window.parent.postMessage(message, parentOrigin);
    }
  }

  window.addEventListener('message', function (event) {
    if (event.origin !== parentOrigin || event.source !== window.parent) {
      return;
    }
    const data = event.data;
    if (!data || typeof data !== 'object') {
      return;
    }

    if (data.type === 'asistanx:init') {
      setExpiry(data.expires_at);
      showFullscreen(data.fullscreen === true);
      if (typeof data.path === 'string' && data.path && !startPath) { goTo(sectionFromPath(data.path), false); }
    } else if (data.type === 'asistanx:fullscreen:changed') {
      showFullscreen(data.fullscreen === true);
    } else if (data.type === 'asistanx:token' && typeof data.token === 'string') {
      token = data.token;
      setExpiry(data.expires_at);
      const resolve = waiting.get(data.id);
      if (resolve) {
        waiting.delete(data.id);
        resolve(true);
      }
    }
  });

  /*
   * Tam ekran: uygulamanız katalogda "Tam ekran açılır" işaretliyse panel onu tüm pencerede açar
   * ve asistanx:init mesajında fullscreen: true bildirir. Kullanıcının panele dönebilmesi için
   * uygulamanızda bir çıkış düğmesi olmalıdır: panele { type: 'asistanx:close' } yollar.
   */
  function showFullscreen(on) {
    const info = document.querySelector('[data-fullscreen-info]');
    if (info) {
      info.textContent = on ? 'Tam ekrandasınız.' : '';
    }
  }

  const closeButton = document.querySelector('[data-close]');
  if (closeButton) {
    closeButton.hidden = !inFrame;
    closeButton.addEventListener('click', function () {
      toParent({ type: 'asistanx:close' });
    });
  }

  /* Panelden yeni anahtar ister; 10 sn içinde gelmezse false döner. */
  function requestToken() {
    if (!inFrame) {
      return Promise.resolve(false);
    }
    return new Promise(function (resolve) {
      const id = nextRequestId++;
      const timer = setTimeout(function () {
        waiting.delete(id);
        resolve(false);
      }, 10000);
      waiting.set(id, function (ok) {
        clearTimeout(timer);
        resolve(ok);
      });
      toParent({ type: 'asistanx:token:request', id: id });
    });
  }

  /* Kendi API'mize istek: 401 gelirse anahtarı bir kez yenileyip yeniden dener. */
  async function api(path, options) {
    const send = function () {
      const init = Object.assign({}, options || {});
      init.headers = Object.assign({ Authorization: 'Bearer ' + token }, init.headers || {});
      if (init.body !== undefined) {
        init.headers['Content-Type'] = 'application/json';
        init.body = JSON.stringify(init.body);
      }
      return fetch(path, init);
    };

    let response = await send();
    if (response.status === 401 && (await requestToken())) {
      response = await send();
    }
    return response;
  }

  /* ---------- Arayüz ---------- */

  const $ = function (selector) { return document.querySelector(selector); };
  const list = $('[data-notes]');
  const empty = $('[data-empty]');
  const input = $('[data-note-input]');
  const addButton = $('[data-note-add]');
  const errorBox = $('[data-error]');

  function formatDate(value) {
    const date = typeof value === 'number' ? new Date(value * 1000) : new Date(value);
    return isNaN(date) ? '—' : date.toLocaleString('tr-TR');
  }

  function setFact(name, value) {
    const el = $('[data-fact="' + name + '"]');
    if (el) { el.textContent = value; }
  }

  function setExpiry(value) {
    if (typeof value === 'number') {
      expiresAt = value;
      setFact('expires', formatDate(expiresAt));
    }
  }

  function showError(message) {
    errorBox.textContent = message || '';
    errorBox.hidden = !message;
  }

  function renderNote(note) {
    const item = document.createElement('li');
    const text = document.createElement('span');
    text.textContent = note.body;
    const meta = document.createElement('small');
    meta.textContent = formatDate(note.created_at) + ' · kullanıcı ' + note.user_id;
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'link';
    remove.textContent = 'Sil';
    remove.addEventListener('click', async function () {
      remove.disabled = true;
      const response = await api('/api/notes/' + note.id, { method: 'DELETE' });
      if (response.ok || response.status === 404) {
        item.remove();
        empty.hidden = list.children.length > 0;
      } else {
        remove.disabled = false;
        showError('Not silinemedi. Yeniden deneyin.');
      }
    });
    const body = document.createElement('div');
    body.append(text, meta);
    item.append(body, remove);
    return item;
  }

  async function loadMe() {
    const response = await api('/api/me');
    if (!response.ok) {
      showError('Oturum doğrulanamadı. Paneldeki "Yenile" düğmesine basın.');
      return false;
    }
    const me = await response.json();
    $('[data-tenant]').textContent = me.tenant_host;
    setFact('tenant_host', me.tenant_host);
    setFact('tenant_id', me.tenant_id);
    setFact('user', (me.user_name || 'Kullanıcı') + ' (#' + me.user_id + ')' + (me.app_manager ? ' · uygulama yetkilisi' : ''));
    setFact('user_scopes', me.user_scopes === null ? 'bildirilmedi' : (me.user_scopes.length ? me.user_scopes.join(', ') : 'yok'));
    setFact('first_seen_at', formatDate(me.first_seen_at));
    setExpiry(me.expires_at);
    return true;
  }

  /* Uygulamanın bu müşterideki izinleri (müşteri anahtarı). Veri okumaz. */
  async function loadConnection() {
    const response = await api('/api/connection');
    const data = response.ok ? await response.json() : { connected: false };
    setFact('app_scopes', data.connected
      ? (data.scopes.length ? data.scopes.join(', ') : 'yok')
      : (data.error === 'no_scopes' ? 'izin verilmemiş' : 'bağlantı kurulamadı'));
    setFact('offline_access', data.connected
      ? (data.offline_access ? 'var: panelde kimse yokken de veri okunabilir' : 'yok: veri yalnız ekrandaki kullanıcının yetkisiyle okunur')
      : '—');
  }

  /* Hata kodunu kullanıcıya gösterilecek iletiye çevirir. Kodunuz `error` alanına bakmalı. */
  function productsMessage(data) {
    switch (data.error) {
      case 'no_scopes':
      case 'insufficient_scope':
        return 'Bu uygulamaya ürünlerinizi görme izni verilmemiş.';
      case 'user_forbidden':
        return 'Ürünleri görme yetkiniz yok. Yetki için yöneticinize başvurun.';
      case 'module_disabled':
      case 'feature_unavailable':
        return 'Bu hesapta Ürünler bölümü açık değil.';
      case 'invalid_session_token':
        return 'Oturumunuz yenileniyor; birazdan yeniden deneyin.';
      default:
        return 'Ürünlere şu anda ulaşılamıyor' + (data.message ? ': ' + data.message : '.');
    }
  }

  /* AsistanX API örneği: ürünleri kendi sunucumuz üzerinden, ekrandaki kullanıcının yetkisiyle okur. */
  async function loadProducts() {
    const info = $('[data-products-info]');
    const box = $('[data-products]');
    const response = await api('/api/products');
    if (!response.ok) {
      info.textContent = 'Ürünler yüklenemedi.';
      return;
    }
    const data = await response.json();
    if (!data.available) {
      info.textContent = productsMessage(data);
      return;
    }
    info.textContent = 'Toplam ' + data.total + ' ürün; ilk ' + data.products.length + ' tanesi:';
    box.replaceChildren.apply(box, data.products.map(function (product) {
      const item = document.createElement('li');
      const body = document.createElement('div');
      const title = document.createElement('span');
      title.textContent = product.title || '(adsız ürün)';
      const meta = document.createElement('small');
      meta.textContent = (product.sku ? 'Stok kodu ' + product.sku + ' · ' : '') + 'stok ' + product.stock;
      body.append(title, meta);
      item.append(body);
      return item;
    }));
  }

  /* Soru uçlarının hata kodları → kullanıcıya gösterilecek ileti. */
  function questionsMessage(data) {
    switch (data.error) {
      case 'no_scopes':
      case 'insufficient_scope':
        return 'Bu uygulamaya müşteri sorularını görme ya da yanıtlama izni verilmemiş.';
      case 'user_forbidden':
        return 'Müşteri sorularında yetkiniz yok. Yetki için yöneticinize başvurun.';
      case 'module_disabled':
      case 'feature_unavailable':
        return 'Bu hesapta müşteri soruları bölümü açık değil.';
      case 'not_found':
        return 'Soru bulunamadı; silinmiş ya da yanıtlanmış olabilir.';
      case 'invalid_reply':
        return data.message;
      default:
        return 'Sorulara şu anda ulaşılamıyor' + (data.message ? ': ' + data.message : '.');
    }
  }

  /*
   * AsistanX API yazma örneği: soruyu yanıtlar. Yanıt pazaryerine gerçekten gönderilir, bu yüzden
   * kullanıcı metni kendisi yazar ve gönderimi açıkça onaylar.
   */
  function renderQuestion(question) {
    const item = document.createElement('li');
    const body = document.createElement('div');
    const title = document.createElement('span');
    title.textContent = question.last_message || '(soru metni yok)';
    const meta = document.createElement('small');
    meta.textContent = [question.marketplace, question.customer_name, question.product_name].filter(Boolean).join(' · ');
    const row = document.createElement('div');
    row.className = 'row';
    const field = document.createElement('input');
    field.type = 'text';
    field.maxLength = 5000;
    field.placeholder = 'Yanıtınız';
    field.setAttribute('aria-label', 'Soru yanıtı');
    const send = document.createElement('button');
    send.type = 'button';
    send.textContent = 'Yanıtla';
    send.addEventListener('click', async function () {
      const message = field.value.trim();
      const errorBox = $('[data-questions-error]');
      if (message === '') {
        field.focus();
        return;
      }
      if (send.dataset.confirm !== '1') {
        send.dataset.confirm = '1';
        send.textContent = 'Gönder (geri alınamaz)';
        return;
      }
      send.disabled = true;
      errorBox.hidden = true;
      const response = await api('/api/questions/' + question.id + '/reply', { method: 'POST', body: { message: message } });
      if (response.status === 201) {
        item.remove();
        return;
      }
      const data = await response.json().catch(function () { return {}; });
      errorBox.textContent = questionsMessage(data);
      errorBox.hidden = false;
      send.disabled = false;
      send.dataset.confirm = '';
      send.textContent = 'Yanıtla';
    });
    row.append(field, send);
    body.append(title, meta, row);
    item.append(body);
    return item;
  }

  async function loadQuestions() {
    const info = $('[data-questions-info]');
    const box = $('[data-questions]');
    const response = await api('/api/questions');
    if (!response.ok) {
      info.textContent = 'Sorular yüklenemedi.';
      return;
    }
    const data = await response.json();
    if (!data.available) {
      info.textContent = questionsMessage(data);
      return;
    }
    info.textContent = data.total === 0 ? 'Cevap bekleyen soru yok.' : 'Cevap bekleyen ' + data.total + ' soru; ilk ' + data.questions.length + ' tanesi:';
    box.replaceChildren.apply(box, data.questions.map(renderQuestion));
  }

  async function loadNotes() {
    const response = await api('/api/notes');
    if (!response.ok) {
      showError('Notlar yüklenemedi.');
      return;
    }
    const data = await response.json();
    list.replaceChildren.apply(list, data.notes.map(renderNote));
    empty.hidden = data.notes.length > 0;
  }

  async function addNote() {
    const body = input.value.trim();
    if (body === '') {
      input.focus();
      return;
    }
    showError('');
    addButton.disabled = true;
    try {
      const response = await api('/api/notes', { method: 'POST', body: { body: body } });
      if (response.status === 201) {
        const data = await response.json();
        list.prepend(renderNote(data.note));
        empty.hidden = true;
        input.value = '';
      } else {
        const data = await response.json().catch(function () { return {}; });
        showError(data.message || 'Not eklenemedi. Yeniden deneyin.');
      }
    } finally {
      addButton.disabled = false;
      input.focus();
    }
  }

  /* Yazdırma uçlarının hata kodları → kullanıcıya gösterilecek ileti. */
  function printMessage(data) {
    switch (data.error) {
      case 'no_scopes':
      case 'insufficient_scope':
        return 'Bu uygulamaya yazdırma izni verilmemiş.';
      case 'no_printer':
      case 'no_notes':
        return data.message;
      case 'user_forbidden':
        return 'Bu uygulamayı kullanma yetkiniz yok.';
      case 'rate_limited':
        return 'Çok fazla yazdırma isteği; biraz bekleyin.';
      default:
        return 'Yazdırılamadı' + (data.message ? ': ' + data.message : '.');
    }
  }

  /*
   * AsistanX yazdırma örneği: notları PDF yapıp kullanıcının departmanındaki A4 yazıcısına gönderir,
   * sonra işin durumunu birkaç kez sorar. Gerçek kâğıt harcar; yalnız düğmeye basılınca çalışır.
   */
  const printButton = $('[data-print]');
  const printInfo = $('[data-print-info]');

  async function loadPrinters() {
    const response = await api('/api/print/printers');
    const data = response.ok ? await response.json() : { available: false };
    if (!data.available) {
      printButton.disabled = true;
      printInfo.textContent = printMessage(data);
      return;
    }
    const slot = data.printers.find(function (item) { return item.paper === 'A4'; });
    printButton.disabled = !slot || !slot.printer;
    printInfo.textContent = slot && slot.printer
      ? 'Yazıcı: ' + slot.printer + (data.department ? ' (' + data.department + ')' : '')
      : (data.department ? data.department + ' departmanına A4 yazıcısı tanımlı değil.' : 'Bir departmana bağlı değilsiniz; yazıcı bulunamadı.');
  }

  async function watchJob(jobId, attempt) {
    const response = await api('/api/print/jobs/' + jobId);
    const data = response.ok ? await response.json() : {};
    if (data.status === 'printed') {
      printInfo.textContent = 'Yazdırıldı.';
    } else if (data.status === 'expired') {
      printInfo.textContent = 'Yazdırılamadı: yazıcı bilgisayarı işi almadı.';
    } else if (attempt < 10) {
      setTimeout(function () { watchJob(jobId, attempt + 1); }, 3000);
      return;
    } else {
      printInfo.textContent = 'Kuyrukta bekliyor; yazıcı bilgisayarının açık olduğunu denetleyin.';
    }
    printButton.disabled = false;
  }

  printButton.addEventListener('click', async function () {
    printButton.disabled = true;
    printInfo.textContent = 'Gönderiliyor…';
    const response = await api('/api/print/notes', { method: 'POST', body: { paper: 'A4' } });
    const data = await response.json().catch(function () { return {}; });
    if (response.status !== 201) {
      printInfo.textContent = printMessage(data);
      printButton.disabled = false;
      return;
    }
    printInfo.textContent = 'Kuyruğa eklendi' + (data.printer ? ': ' + data.printer : '') + '. Bekleniyor…';
    watchJob(data.job_id, 0);
  });

  /* E-posta bildirimi uçlarının hata kodları → kullanıcıya gösterilecek ileti. */
  const MAIL_REASONS = {
    not_found: 'kullanıcı bulunamadı',
    inactive: 'kullanıcı pasif',
    no_email: 'kullanıcının e-posta adresi yok',
    no_app_access: 'bu uygulamayı açma yetkiniz yok',
    email_suppressed: 'adresiniz engelleme listesinde (daha önce geri döndü)',
    not_panel_user: 'panel kullanıcısı değilsiniz',
  };
  function mailMessage(data) {
    switch (data.error) {
      case 'no_scopes':
      case 'insufficient_scope':
        return 'Bu uygulamaya e-posta bildirimi izni verilmemiş.';
      case 'no_valid_recipients': {
        const reason = data.rejected && data.rejected[0] ? MAIL_REASONS[data.rejected[0].reason] : null;
        return 'E-posta gönderilemedi' + (reason ? ': ' + reason + '.' : '.');
      }
      case 'mail_limit_reached':
        return 'Bu uygulamanın bugünkü e-posta sınırı doldu; yarın yeniden deneyin.';
      case 'rate_limited':
      case 'conflict':
        return 'Çok sık gönderim; biraz bekleyip yeniden deneyin.';
      case 'invalid_mail':
      case 'validation_failed':
        return data.message || 'Konu ya da ileti hatalı.';
      default:
        return 'E-posta gönderilemedi' + (data.message ? ': ' + data.message : '.');
    }
  }

  /* AsistanX e-posta bildirimi örneği: oturumdaki kullanıcıya (yalnız kendisine) gönderir. */
  const mailButton = $('[data-mail-send]');
  const mailInfo = $('[data-mail-info]');
  mailButton.addEventListener('click', async function () {
    const subject = $('[data-mail-subject]').value.trim();
    const text = $('[data-mail-text]').value.trim();
    if (subject === '' || text === '') {
      mailInfo.textContent = 'Konu ve ileti boş olamaz.';
      return;
    }
    mailButton.disabled = true;
    mailInfo.textContent = 'Gönderiliyor…';
    try {
      const response = await api('/api/mail/self', { method: 'POST', body: { subject: subject, text: text } });
      const data = await response.json().catch(function () { return {}; });
      mailInfo.textContent = response.status === 202 && data.accepted && data.accepted.length
        ? 'Kuyruğa alındı; birkaç dakika içinde e-posta kutunuza düşer.'
        : mailMessage(data);
    } finally {
      mailButton.disabled = false;
    }
  });

  addButton.addEventListener('click', addNote);
  input.addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      addNote();
    }
  });

  /*
   * ADRES EŞİTLEME. Bölüm değişince panele { type: 'asistanx:navigate', path } yollanır; panel adresi
   * /admin/apps/<uygulama>/notlar olur. Kullanıcı sayfayı yenileyince panel yolu `path` parametresiyle
   * geri verir ve aynı bölüm açılır. Gelen yol kullanıcının adres çubuğundandır: yalnız bilinen bölümlere
   * eşlenir, bilinmeyen yol ilk bölümü açar.
   */
  const SECTIONS = ['oturum', 'urunler', 'sorular', 'notlar', 'eposta'];
  function sectionFromPath(path) {
    const name = String(path || '').split('?')[0].replace(/^\/+|\/+$/g, '');
    return SECTIONS.indexOf(name) !== -1 ? name : 'oturum';
  }
  function goTo(section, notify) {
    if (SECTIONS.indexOf(section) === -1) { section = 'oturum'; }
    document.querySelectorAll('[data-goto]').forEach(function (link) {
      if (link.dataset.goto === section) { link.setAttribute('aria-current', 'page'); } else { link.removeAttribute('aria-current'); }
    });
    document.querySelectorAll('[data-section]').forEach(function (card) {
      card.classList.toggle('is-current', card.dataset.section === section);
    });
    const target = document.querySelector('[data-section="' + section + '"]');
    if (target && section !== 'oturum') { target.scrollIntoView({ block: 'start' }); }
    if (notify) { toParent({ type: 'asistanx:navigate', path: section === 'oturum' ? '/' : '/' + section }); }
  }
  document.querySelectorAll('[data-goto]').forEach(function (link) {
    link.addEventListener('click', function (event) {
      event.preventDefault();
      goTo(link.dataset.goto, true);
    });
  });
  goTo(sectionFromPath(startPath), false);

  toParent({ type: 'asistanx:ready' });
  loadMe().then(function (ok) {
    if (ok) { loadNotes(); loadConnection(); loadProducts(); loadQuestions(); loadPrinters(); }
  });
})();
