# AsistanX Starter App

AsistanX App Store için örnek uygulama. Kendi uygulamanızı yazarken bu projeyi kopyalayıp
üzerine kurabilirsiniz. Node.js + Express ile yazılmıştır; veritabanı olarak Node'un
yerleşik SQLite sürücüsünü kullanır (ek kurulum gerekmez).

Uygulamanız **kendi sunucunuzda** çalışır. AsistanX onu müşterinin panelinde bir iframe
içinde açar ve kim olduğunu imzalı bir oturum anahtarıyla bildirir.

## Nasıl çalışır

1. Geliştirici portalında (https://asistanx.com/app-devops) hesap açıp uygulamanızı eklersiniz.
   Portal size iki bilgi verir: **uygulama kimliği** (`client_id`) ve **gizli anahtar**
   (`client_secret`). Taslak uygulamanızı deneme koduyla bir AsistanX panelinde kurup
   deneyebilir, hazır olunca incelemeye gönderirsiniz.
2. Müşteri uygulamayı panelindeki App Store'dan kurar; menüsüne eklenir.
3. Müşteri menüden açınca panel, uygulama adresinizi iframe içinde şöyle çağırır:

   ```
   https://uygulamaniz.com/app?tenant=musteri.com&token=<oturum anahtarı>
   ```

4. Sunucunuz anahtarı gizli anahtarınızla doğrular. Geçerliyse hangi müşterinin hangi
   kullanıcısının açtığını kesin olarak bilirsiniz.
5. Tarayıcıdaki kodunuz kendi sunucunuza her istekte anahtarı
   `Authorization: Bearer <anahtar>` başlığıyla yollar.
6. Anahtar 5 dakika geçerlidir. Panel, süresi dolmadan yenisini `postMessage` ile iletir.

## Oturum anahtarı

HS256 ile imzalı bir JWT'dir. İçeriği:

| Alan | Anlamı |
|---|---|
| `iss` | Müşteri panelinin adresi, örn. `https://musteri.com` |
| `aud` | Uygulama kimliğiniz. Sizinkiyle aynı değilse reddedin. |
| `sub` | Paneldeki kullanıcının numarası (metin) |
| `tenant` | Müşterinin değişmeyen kimliği. Verinizi buna göre ayırın. |
| `dest` | Müşterinin alan adı, örn. `musteri.com` |
| `iat`, `nbf`, `exp` | Verilme ve bitiş zamanı (5 dakika) |
| `jti` | Anahtarın tekil numarası |
| `user` | `{ "id": 12, "name": "Ayşe Yılmaz", "app_manager": false }`. `app_manager`: bu kullanıcı müşterinin panelinde uygulama kurup izin verebiliyor mu. |
| `user_scopes` | Bu kullanıcının yetkili olduğu izinler, örn. `["siparisler:read"]`: uygulamanızın izinleri ile kullanıcının panel yetkisinin kesişimi. |

Anahtar e-posta taşımaz ve tek başına AsistanX API'sine erişim vermez; kimlik kanıtıdır.
`user_scopes` listesini ekranınızı çizerken kullanın: kullanıcının yetkili olmadığı bölümü
göstermeyin. Asıl denetim API'dedir; aşağıdaki "Kullanıcıya bağlı anahtar" bölümüne bakın.

Doğrularken uyulması gerekenler ([src/session.js](src/session.js)):

- Yalnız `HS256` kabul edin.
- `aud` değerini kendi uygulama kimliğinizle karşılaştırın.
- `iss` değerinin `https://` + `dest` olduğunu denetleyin.
- Müşteriyi alan adına göre değil `tenant` değerine göre tanıyın; alan adı değişebilir.

## Çok müşterili yapı

Her müşteri `installations` tablosunda bir satırdır; uygulama müşteriyi ilk oturum
anahtarında kendiliğinden kaydeder. Müşteriye ait her tablo `installation_id` taşır ve her
sorgu bununla süzülür ([src/db.js](src/db.js)). Örnekteki "Notlar" bunu gösterir: bir
müşterinin notunu başka müşteri ne görebilir ne silebilir.

Kendi tablolarınızı eklerken aynı kuralı uygulayın.

## Panel ile köprü (postMessage)

Uygulamanız iframe içinde olduğu için panelle `window.parent.postMessage` üzerinden konuşur.
Örnek istemci: [public/app.js](public/app.js).

| Yön | Mesaj | Açıklama |
|---|---|---|
| Uygulama → panel | `{ type: 'asistanx:ready' }` | Sayfa yüklendi. |
| Panel → uygulama | `{ type: 'asistanx:init', app, tenant, expires_at }` | `ready` yanıtı. |
| Uygulama → panel | `{ type: 'asistanx:token:request', id }` | Yeni anahtar isteği. |
| Panel → uygulama | `{ type: 'asistanx:token', id, token, expires_at }` | Yeni anahtar. Panel bunu süre dolmadan 60 sn önce kendiliğinden de yollar (`id` boş gelir). |

Mesaj alırken `event.origin` değerinin anahtardaki panel adresi (`iss`) ve `event.source`
değerinin `window.parent` olduğunu denetleyin. Mesaj yollarken hedef adres olarak `*`
kullanmayın, panel adresini verin.

## iframe kuralları

- **Yalnız https.** Uygulama adresiniz `https://` ile başlamalıdır.
- **Gömülmeye izin verin.** Sunucunuz `X-Frame-Options` başlığı göndermemeli; bunun yerine
  `Content-Security-Policy: frame-ancestors https://<müşteri alan adı>` gönderin. Örnek
  bunu anahtardaki müşteriye göre ayarlar ([src/app.js](src/app.js)).
- **Çereze güvenmeyin.** Tarayıcılar iframe içindeki üçüncü taraf çerezlerini engeller.
  Oturumu çerezle değil, her istekte gönderilen anahtarla taşıyın.
- **Üst pencereyi yönlendiremezsiniz.** Ödeme gibi akışlar için yeni pencere açabilirsiniz
  (`window.open`).
- **Ücretlendirme size aittir.** Ödemeyi kendi uygulamanızın içinde alırsınız.

## Kurulum

Node.js 22.13 veya üstü gerekir.

```bash
npm install
cp .env.example .env   # ASISTANX_CLIENT_ID ve ASISTANX_CLIENT_SECRET değerlerini girin
npm test
npm start
```

Canlıda süreci ayakta tutmak için PM2:

```bash
pm2 start ecosystem.config.cjs
pm2 save
```

Uygulama `127.0.0.1:5485` adresini dinler; önüne https sonlandıran bir vekil (nginx)
koyun.

## Uçlar

| Uç | Açıklama |
|---|---|
| `GET /app?tenant=…&token=…` | Panelin iframe içinde açtığı giriş sayfası |
| `GET /api/me` | Oturumdaki müşteri ve kullanıcı |
| `GET /api/connection` | Uygulamanın bu müşterideki izinleri ve arka planda erişim durumu (müşteri anahtarı; veri döndürmez) |
| `GET /api/products` | Müşterinin AsistanX'teki ürünlerinden ilk 10'u, ekrandaki kullanıcının yetkisiyle (kullanıcı anahtarı örneği) |
| `GET /api/questions` | Cevap bekleyen müşteri soruları, ekrandaki kullanıcının yetkisiyle (okuma örneği) |
| `POST /api/questions/:id/reply` | Soruyu yanıtlar: `{ "message": "…" }` (yazma örneği; yanıt pazaryerine gerçekten gönderilir) |
| `GET /api/print/printers` | Ekrandaki kullanıcının departmanındaki yazıcılar (yazdırma örneği) |
| `POST /api/print/notes` | Notları PDF yapıp kullanıcının yazıcısına gönderir: `{ "paper": "A4" }` (gerçek kâğıt harcar) |
| `GET /api/print/jobs/:id` | Yazdırma işinin durumu |
| `POST /api/mail/self` | Oturumdaki kullanıcıya e-posta bildirimi gönderir: `{ "subject": "…", "text": "…" }` (e-posta örneği; gerçek e-posta gider) |
| `GET /api/notes` | Müşterinin notları |
| `POST /api/notes` | Not ekler: `{ "body": "…" }` |
| `DELETE /api/notes/:id` | Not siler |
| `POST /webhooks/asistanx` | AsistanX olay bildirimleri (imzalı) |
| `POST /whatsapp/asistanx` | AsistanX WhatsApp komutları (imzalı): metin, dosya, soru ya da geç yanıt döner |
| `GET /whatsapp/files/:key/:name` | WhatsApp'a gönderilen dosyanın kısa ömürlü indirme adresi |
| `GET /healthz` | Sağlık denetimi |

`/api/*` uçlarının tümü `Authorization: Bearer <oturum anahtarı>` ister.

## AsistanX API'sine erişim

Uygulamanız müşterinin verisine (ürün, sipariş, kargo…) AsistanX API'siyle erişir. Örnek:
[src/asistanx-api.js](src/asistanx-api.js).

**1. İzin isteyin.** Uygulamanızı geliştirici portalında eklerken hangi alanlarda okuma ya da yazma
izni istediği belirlenir. Müşteri kurarken bu listeyi görür ve onaylar.

| İzin | Kapsadığı API yolları (`/api/v1/mobile/` altında) |
|---|---|
| `urunler:read` / `urunler:write` | `products` |
| `siparisler:read` / `siparisler:write` | `orders`, `order-items` |
| `kargo:read` / `kargo:write` | `cargo` |
| `eslestirme:read` / `eslestirme:write` | `matchings` |
| `uretim:read` / `uretim:write` | `manufacturing` |
| `gorevler:read` / `gorevler:write` | `tasks` |
| `sorular:read` / `sorular:write` | `questions` |
| `raporlar:read` | `dashboard`, `reports`, `orders/report`, `orders/export` |
| `eposta:read` | veri alanı değil: `POST /api/v1/apps/mail` (e-posta bildirimi) |

Okuma `GET` isteklerini, yazma diğer tüm istekleri kapsar; yazma izni okumayı da içerir.
Yapay zekâ uçları ve bu tabloda olmayan uçlar uygulamalara kapalıdır.

**2. Anahtarı alın.** Sunucunuzdan, müşterinin alan adına:

```
POST https://musteri.com/api/v1/apps/token
Content-Type: application/json

{ "client_id": "axapp_…", "client_secret": "axsec_…" }
```

```json
{
  "access_token": "axat_…",
  "token_type": "Bearer",
  "scopes": ["urunler:read"],
  "tenant": "musteri",
  "api_base": "https://musteri.com/api/v1/mobile"
}
```

- Bu isteği yalnız sunucunuzdan yapın; gizli anahtarı tarayıcıya koymayın.
- Her istek yeni anahtar üretir ve öncekini iptal eder. Anahtarı (şifreli) saklayın ve
  yeniden kullanın.
- Hatalar: `401 invalid_client`, `403 not_installed`, `403 no_scopes`, `403 app_disabled`.
- Bu uç dakikada 20 istekle sınırlıdır (`429`). Reddedilen isteği hemen yinelemeyin; örnek,
  olumsuz yanıtı 60 saniye hatırlar ve bu sürede yeniden sormaz.

Bu, **müşteri anahtarıdır**: müşterinin uygulamanıza verdiği izinlerin tamamıyla çalışır ve
süresizdir. Arka plan işleriniz ve bildirim işleme için kullanın. Bu anahtarla yapılan işlemler,
müşterinin hesabında uygulamanıza özel açılan bir kullanıcı adına kaydedilir.

**Kullanıcıya bağlı anahtar.** Ekrandaki kişiye veri gösterirken ya da onun adına işlem yaparken,
aynı uca panelden aldığınız oturum anahtarını da gönderin:

```
POST https://musteri.com/api/v1/apps/token
Content-Type: application/json

{ "client_id": "axapp_…", "client_secret": "axsec_…", "session_token": "<oturum anahtarı>" }
```

```json
{
  "access_token": "axut_…",
  "token_type": "Bearer",
  "access_mode": "user",
  "expires_in": 3600,
  "scopes": ["siparisler:read"],
  "user": { "id": 12, "name": "Ayşe Yılmaz" },
  "tenant": "musteri",
  "api_base": "https://musteri.com/api/v1/mobile"
}
```

- Anahtar **1 saat** geçerlidir ve o kullanıcıya bağlıdır. Süresi dolunca (`401 token_expired`)
  panelden gelen güncel oturum anahtarıyla yenisini alın. Örnek, anahtarı bellekte tutar ve
  süre dolmadan bir dakika önce yeniler.
- Bu anahtarla yapılan her istekte API, uygulamanızın izninin yanında **kullanıcının panel
  yetkisine de bakar**. Kullanıcı yetkili değilse `403 user_forbidden` döner; bunu "bu bölümü
  görme yetkiniz yok" diye gösterin.
- Müşteri anahtarını ekrandaki kişiye veri göstermek için kullanmayın; kullanıcının yetkisini
  atlamış olursunuz. Bu bir inceleme ölçütüdür. Örnekte ürün listesi kullanıcı anahtarıyla
  okunur (`getAsUser`); müşteri anahtarı yalnız bağlantı durumunu göstermek için alınır.
- Ek hatalar: `401 invalid_session_token`, `403 user_forbidden` (kullanıcı pasif ya da müşterinin
  yöneticisi ona uygulamanızı açma erişimi vermemiş).

**3. API'yi çağırın.**

```
GET https://musteri.com/api/v1/mobile/products?per_page=10
Authorization: Bearer axat_…
```

Uygulamanıza dönen her hata aynı biçimdedir; kodunuzda `error` alanına bakın, `message`
insan için açıklamadır:

```json
{ "error": "user_forbidden", "message": "Bu işlem için yetkiniz yok. Yetki için yöneticinize başvurun." }
```

| HTTP | Kod | Anlamı |
|---|---|---|
| 401 | `invalid_token` | Anahtar geçersiz ya da iptal edilmiş (örneğin müşteri kaldırıp yeniden kurmuş). Yeni anahtar alın. |
| 401 | `token_expired` | Kullanıcı anahtarının süresi dolmuş. Oturum anahtarıyla yenisini alın. |
| 403 | `insufficient_scope` | Bu işlem için gereken izin uygulamanızda yok ya da müşteri henüz onaylamamış. |
| 403 | `user_forbidden` | Kullanıcının bu veriye ya da uygulamanıza yetkisi yok. Müşteri anahtarına geçmeyin. |
| 403 | `module_disabled` | Müşterinin hesabında bu modül açık değil. |
| 403 | `feature_unavailable` | Bu özellik AsistanX genelinde kapalı. |
| 403 | `endpoint_not_available` | Bu uç uygulamalara açık değil. |
| 404 | `not_found` | Kayıt ya da adres yok. |
| 422 | `validation_failed` | Gönderilen veri hatalı; alan hataları `errors` içinde. |
| 429 | `rate_limited` | Çok fazla istek. Bekleyip yeniden deneyin. |
| 5xx | `server_error` | AsistanX tarafında beklenmeyen hata. |

Tam liste: https://asistanx.com/app-devops/docs/hata-kodlari

Uçların ayrıntısı: https://asistanx.com/docs/

Kayıtlarda işlem, müşteri anahtarında uygulamanıza özel açılan kullanıcı adına, kullanıcı
anahtarında ekrandaki kullanıcı adına görünür.

## Arka planda erişim

Müşteri anahtarı (`axat_…`) veri uçlarında yalnız müşteri uygulamanıza **"Arka planda erişim"**
iznini (`arkaplan:read`) verdiyse çalışır. Vermediyse `403 user_required` döner ve veri yalnız
ekrandaki kullanıcıya bağlı anahtarla, o kullanıcının yetkisi kadar okunabilir. Bu izni yalnız
gerçekten arka plan işiniz varsa (zamanlanmış iş, bildirim işleme, eşitleme) isteyin.

Anahtar ucunun yanıtındaki `offline_access` alanı durumu bildirir. Örnekte `GET /api/connection`
bunu döner ve "Oturum" kartında "Arka planda erişim: var / yok" olarak gösterilir.

## Tam ekran

Uygulamanızı portalda "Tam ekran açılır" olarak işaretlerseniz panel onu tüm pencerede açar; panelin
menüsü ve çubukları görünmez. Panel açılışta `asistanx:init` mesajında `fullscreen: true` bildirir.

- Kullanıcının panele dönebilmesi için bir çıkış düğmesi koyun: panele `{ type: 'asistanx:close' }`
  yollar. Örnekte başlıktaki "Panele dön" düğmesi böyle çalışır ([public/app.js](public/app.js)).
- Çalışırken tam ekrana girip çıkmak için `{ type: 'asistanx:fullscreen', enabled: true|false }`;
  panel `asistanx:fullscreen:changed` ile yanıtlar. Yalnız "Tam ekran açılır" işaretli uygulamada geçerlidir.
- Sağ üst köşedeki 44×44 piksellik alana düğme koymayın; panelin kendi çıkış düğmesi orada durur.

## Adres eşitleme

Uygulamanız iframe içinde çalıştığı için kendi sayfa değişimleri panel adresine yansımaz; kullanıcı
sayfayı yenileyince uygulama baştan açılır. Uygulama içi sayfanızı panele bildirin:

```js
window.parent.postMessage({ type: 'asistanx:navigate', path: '/notlar' }, panelAdresi);
```

Panel adresi `/admin/apps/<uygulama>/notlar` olur (sayfa yeniden yüklenmez). Yenilemede ya da
paylaşılan adreste panel yolu uygulama adresine `path` parametresiyle ekler
(`/app?tenant=…&token=…&path=%2Fnotlar`) ve `asistanx:init` mesajında da `path` olarak verir.

- Yol `/` ile başlar, en çok 512 karakterdir; `//`, `.`/`..` bölümü, `#`, ters bölü ve boşluk içeremez.
- `path` kullanıcının adres çubuğundan gelir: yalnız bildiğiniz sayfalara eşleyin.
- Örnek: başlığın altındaki bölüm sekmeleri (`goTo`, `sectionFromPath`) — [public/app.js](public/app.js).

## Müşteri soruları: okuma ve yazma örneği

Pazaryeri ve vitrin ürün soruları AsistanX'te aynı kutudadır (`questions` uçları). Örnek:
`src/app.js` içindeki `/api/questions` ve `/api/questions/:id/reply`, arayüzü `public/app.js`
(`loadQuestions`, `renderQuestion`).

- **İzin:** uygulamanız "Müşteri soruları" alanında okuma (`sorular:read`), yanıtlamak için ayrıca
  yazma (`sorular:write`) izni istemelidir. Kullanıcının panelde soru ekranı yetkisi de aranır.
- **Okuma:** `asistanx.getAsUser(installation, session, 'questions', { status: 'NEW' })`.
- **Yazma:** `asistanx.postAsUser(installation, session, 'questions/45/reply', { message })`.
  Yanıt **pazaryerine gerçekten gönderilir ve geri alınamaz**: yalnız kullanıcının yazıp onayladığı
  metinle çağırın, arka plan işinden ya da denemek için çağırmayın. Örnek arayüz gönderimden önce
  ikinci bir tıklama ister.
- 401 dışındaki hatalarda yazma isteği yinelenmez (aynı yanıt iki kez gitmesin).
- Yapay zekâ uçları (`ai-suggest`, `ai-reply`) uygulamalara kapalıdır: `403 endpoint_not_available`.
- Yeni soru geldiğinde `question.created` bildirimi alırsınız (bkz. Olay bildirimleri).

Uçların tamamı: https://asistanx.com/docs/musteri-sorulari.html


> **Kullanıcı anahtarını aynı anda birden çok kez istemeyin.** AsistanX, bir kullanıcı için yeni anahtar
> verdiğinde öncekini iptal eder. Sayfanız açılırken paralel giden istekler ayrı ayrı anahtar isterse
> birbirlerinin anahtarını geçersiz kılar ve `401` alır. `src/asistanx-api.js` süren isteği paylaşır
> (`requestUserAccess`) ve 401 sonrası, anahtar zaten yenilenmişse yenisini istemez (`renewUserAccess`).

## Yazdırma: PDF'i müşterinin yazıcısından çıkarma

Uygulamanız hazırladığı bir PDF'i, ekrandaki kullanıcının departmanındaki yazıcıdan yazdırabilir.
Örnek: `src/app.js` içindeki `/api/print/*` uçları, PDF üretimi `src/pdf.js`, arayüz `public/app.js`
(`loadPrinters`, `watchJob`).

- **İzin:** "Yazdırma" alanında okuma (`yazdirma:read`: yazıcılar, iş durumu), göndermek için yazma
  (`yazdirma:write`).
- **Kullanıcıya bağlı anahtar zorunludur** (`getAsUser` / `postAsUser`). Yazıcı o kullanıcının
  departmanından bulunur; müşteri (arka plan) anahtarıyla `403 user_required` döner.
- **Yazıcıyı siz seçemezsiniz**, yalnız kâğıt türünü: `A4`, `A5`, `barcode`.
- **PDF'i siz hazırlarsınız.** `content_base64` ile içeriği ya da `url` ile `https` adresini gönderin
  (adresi AsistanX indirir; oturum gerektirmemeli). En fazla 10 MB, 20 kopya.
- `201` belgenin kuyruğa girdiğini söyler. Sonucu `printing/jobs/{id}` ile izleyin:
  `waiting` → `printed`, ya da 30 dakikada alınmazsa `expired`.
- Gerçek kâğıt harcar: yalnız kullanıcının isteğiyle çağırın, hatada kendiliğinden yinelemeyin.
- `src/pdf.js` yalnız örnek içindir (tek sayfa, Türkçe harfleri Latin'e çevirir); gerçek uygulamada
  bir PDF kütüphanesi kullanın.

Uçların tamamı: https://asistanx.com/docs/yazdirma.html

## E-posta bildirimi: panel kullanıcılarına e-posta

Uygulamanız, müşterinin panel kullanıcılarına kendi adına e-posta bildirimi gönderebilir. Örnek:
`src/asistanx-api.js` (`sendMail`), `src/app.js` (`/api/mail/self`), arayüz `public/app.js`
("E-posta bildirimi gönder (kendime)" kartı).

```
POST https://<müşteri alan adı>/api/v1/apps/mail
Authorization: Bearer axat_…
{ "to_user_ids": [12], "subject": "Rapor hazır", "text": "…",
  "action": { "label": "Raporu aç", "url": "https://uygulamaniz.com/rapor/5" },
  "idempotency_key": "rapor-5" }
→ 202 { "id": "…", "accepted": [12], "rejected": [] }
```

- **İzin:** "E-posta bildirimi" (`eposta:read`). Veri alanı değildir; arka planda erişim izni
  gerekmez, müşteri anahtarıyla arka plan işinizden de gönderebilirsiniz. Yoksa `403 insufficient_scope`.
- **Alıcı yalnız müşterinin panel kullanıcısıdır** (`to_user_ids`, 1–20; oturum anahtarındaki `sub`).
  E-posta adresi verilemez. Pasif, silinmiş, uygulamayı açamayan kullanıcılar `rejected` listesine
  nedeniyle (`inactive`, `not_found`, `no_app_access`, …) yazılır; hiçbiri uygun değilse
  `422 no_valid_recipients`.
- **Gövde:** `text` (en fazla 20.000 karakter) ya da `html` (en fazla 100 KB; betik, iframe, form, görsel,
  stil ve `on…` öznitelikleri silinir). Konu en fazla 150 karakter.
- **Düğme** (`action`): adres `https` olmalı, alan adı uygulamanızın adresi (`app_url`) ya da müşterinin
  panel alan adı olmalı.
- **`idempotency_key`** verin: aynı anahtar 24 saat içinde ikinci e-postayı göndermez; ağ hatasından
  sonra güvenle yineleyebilirsiniz.
- **Sınır:** müşteri başına günde 500 alıcı (`429 mail_limit_reached`). E-posta AsistanX'in şablonuyla
  gider: başlıkta "<uygulamanız> uygulamasından bildirim", altbilgide hangi panelde kurulu hangi
  uygulamanın gönderdiği yazar.

Ayrıntı: https://asistanx.com/app-devops/docs/eposta-bildirimleri

## WhatsApp komutları

AsistanX müşterileri WhatsApp'tan yazarak işlerini sorar. Uygulamanız bu asistana kendi
komutlarını ekleyebilir; kullanıcının isteği komutunuza uyarsa AsistanX isteği sunucunuza iletir
ve yanıtınızı kullanıcıya WhatsApp'tan yazar. Örnek: [src/whatsapp.js](src/whatsapp.js).

**1. Tanımlayın.** Geliştirici portalında uygulamanıza "WhatsApp komut adresi"
(`https://uygulamaniz.com/whatsapp/asistanx`) ve komutları girin, **WhatsApp** iznini isteyin:

```json
[
  { "key": "not_ozeti", "title": "Not özeti",
    "trigger": "Kullanıcı Starter App notlarını ya da kaç notu olduğunu sorarsa",
    "senders": ["personnel", "group"] },
  { "key": "urun_sayisi", "title": "Ürün sayısı",
    "trigger": "Kullanıcı Starter App üzerinden toplam ürün sayısını sorarsa",
    "senders": ["personnel"] },
  { "key": "not_ekle", "title": "Not ekle",
    "trigger": "Kullanıcı Starter App'e not eklemek ya da not kaydetmek isterse",
    "params": "metin (isteğe bağlı): kaydedilecek notun metni",
    "senders": ["personnel", "group"] },
  { "key": "not_dokumu", "title": "Not dökümü",
    "trigger": "Kullanıcı Starter App notlarının dökümünü ya da dosyasını isterse",
    "senders": ["personnel", "group"] }
]
```

`senders`: `personnel` (panel kullanıcısı), `group` (WhatsApp grubu), `costumer` (cari),
`guest` (tanınmayan numara). `trigger` metnini dar ve açık yazın; asistan buna bakarak karar verir.

**2. Yanıtlayın.** AsistanX, olay bildirimleriyle aynı imzayla `whatsapp.command` olayını gönderir;
10 saniye içinde `200` ve `{ "text": "…" }` dönün (en fazla 3.500 karakter).

- Telefon numarası gelmez. `sender.user` yalnız soran kişi müşterinin panel kullanıcısıysa doludur.
- Müşterinin verisini okurken `session_token` ile **kullanıcıya bağlı anahtar** alın. Örnekte
  `urun_sayisi` böyle çalışır: kullanıcının panelde Ürünler yetkisi yoksa "yetkiniz yok" yanıtı döner.
- Yanıtınız kullanıcıya olduğu gibi iletilir. Süreyi aşan ya da `text` içermeyen yanıtta kullanıcıya
  "uygulama şu anda yanıt vermiyor" yazılır.

**3. Metinden fazlası.** Yanıt dosya, soru ya da geç yanıt da olabilir; örneklerin hepsi
`src/whatsapp.js` içindedir:

| Örnek komut | Gösterdiği | Yanıt |
|---|---|---|
| `not_ozeti`, `urun_sayisi` | Düz metin; kullanıcının yetkisiyle veri okuma | `{ text }` |
| `not_ekle` | Çok adımlı konuşma: serbest cevap bekleme, sonra seçenekli onay | `expect_reply` + `state`, sonra `options` + `state` |
| `not_dokumu` | Geç yanıt ve dosya gönderme | `{ defer: true }`, sonra `reply.url` adresine `text` + `media` |

- Her adım **aynı komuta** yeni bir istek olarak gelir. Aradaki bilgiyi `state` ile taşıyın; `state`
  her yanıtta yeniden yazılır, göndermezseniz silinir. Bir adımın hiç gelmemesine dayanıklı olun.
- Geç yanıtta gizli anahtarınızı yalnız müşterinin kendi adresine gönderin: örnekteki `replyUrlFor`
  adresi imzası doğrulanmış `dest` alanından kurar ve istekteki `reply.url` ile karşılaştırır.
  Anahtar 10 dakika geçerli ve tek kullanımlıktır.
- Dosya adresi `https` olmalı ve oturum gerektirmemelidir (WhatsApp ağ geçidi indirir); örnek,
  10 dakika geçerli, tahmin edilemeyen bir adres üretir.

Ayrıntı: https://asistanx.com/app-devops/docs/whatsapp-komutlari

## Olay bildirimleri (webhook)

AsistanX, müşteri tarafında bir şey olduğunda sunucunuza haber verir; sürekli sormanız
gerekmez. Bildirim adresinizi geliştirici portalında uygulamanıza girersiniz (yalnız https).
Örnek alıcı: [src/webhooks.js](src/webhooks.js), adresi `POST /webhooks/asistanx`.

| Olay | Ne zaman | `data` |
|---|---|---|
| `app.installed` | Müşteri uygulamayı kurdu | `{ "scopes": [...] }` |
| `app.uninstalled` | Müşteri uygulamayı kaldırdı | `{}` |
| `app.scopes_updated` | Müşteri yeni izinleri onayladı | `{ "scopes": [...] }` |
| `order.created` | Yeni sipariş geldi | `{ "order_id": 123 }` |
| `order.ready_to_ship` | Sipariş kargolanmaya hazır | `{ "order_id": 123 }` |
| `order.shipped` | Sipariş kargolandı | `{ "order_id": 123 }` |
| `order.cancelled` | Sipariş iptal edildi | `{ "order_id": 123 }` |
| `order.returned` | Sipariş iade edildi | `{ "order_id": 123 }` |
| `question.created` | Yeni müşteri sorusu geldi | `{ "question_id": 45 }` |

`order.*` olayları yalnız müşteri "Siparişler" alanında, `question.created` yalnız "Müşteri
soruları" alanında okuma izni verdiyse gönderilir. `app.*` olayları izin gerektirmez.

```
POST https://uygulamaniz.com/webhooks/asistanx
X-AsistanX-Event: app.installed
X-AsistanX-Delivery: 5b0c…            (bildirimin tekil numarası)
X-AsistanX-Timestamp: 1767261600      (saniye)
X-AsistanX-Signature: sha256=…

{ "id": "5b0c…", "event": "app.installed", "app": "uygulamaniz", "tenant": "musteri",
  "dest": "musteri.com", "occurred_at": "2026-01-01T10:00:00Z", "data": { "scopes": ["urunler:read"] } }
```

Bildirim kişisel veri ya da kayıt içeriği taşımaz; ayrıntıyı API anahtarınızla okursunuz.

Alırken uyulması gerekenler:

- **İmzayı doğrulayın.** `sha256=` + HMAC-SHA256(gizli anahtarınız, `<zaman>.<ham gövde>`).
  Ham gövde üzerinden hesaplayın (JSON'u çözüp yeniden yazmayın) ve sabit zamanlı karşılaştırın.
- **Eski bildirimi reddedin.** Zaman damgası 5 dakikadan eskiyse kabul etmeyin.
- **Bir kez işleyin.** Aynı bildirim yeniden gelebilir; `id` değerine göre tekrarı yok sayın.
- **Sıraya güvenmeyin.** Bildirimler birkaç saniye gecikebilir ve sırasız gelebilir. Müşteri
  kaldırıp hemen yeniden kurarsa kaldırma bildirimi, siz yeni API anahtarını aldıktan sonra
  ulaşabilir; `occurred_at` elinizdeki anahtardan eskiyse o bildirimi yok sayın.
- **Hızlı yanıt verin.** 10 saniye içinde `2xx` dönün. `5xx`, `408`, `429` ve bağlantı hatasında
  AsistanX 1 dk, 5 dk, 30 dk, 2 saat ve 6 saat sonra yeniden dener; diğer yanıtlarda denemez.
- **Tanımadığınız olayı yok sayın** (`2xx` dönün); ileride yeni olaylar eklenecek.
- Yönlendirme (3xx) izlenmez.

Kaldırma bildirimi gelince o müşterinin API anahtarını silin. Müşterinin verisini saklayıp
saklamayacağınız size kalmıştır; örnek saklar, yeniden kurulumda geri gelir.

## Henüz olmayanlar

- **Kargo ve stok olayları:** Kargo durumu ve stok değişimi henüz iletilmiyor.
- **Kapatılan uygulama:** AsistanX uygulamanızı geçici olarak kapattıysa bildirim gönderilmez.
