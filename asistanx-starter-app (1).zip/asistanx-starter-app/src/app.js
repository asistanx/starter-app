import { randomUUID } from 'node:crypto';
import express from 'express';
import { resolve } from 'node:path';
import { rootDir } from './paths.js';
import { requireSession, verifySessionToken } from './session.js';
import { createWebhookHandler } from './webhooks.js';
import { createWhatsappHandler } from './whatsapp.js';
import { textPdf } from './pdf.js';

const escapeHtml = (value) =>
  String(value).replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);

function page({ title, body, bodyAttrs = '' }) {
  return `<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>${escapeHtml(title)}</title>
<link rel="stylesheet" href="/static/app.css">
</head>
<body${bodyAttrs}>
${body}
</body>
</html>`;
}

export function createApp({ config, db, asistanx, now = Date.now, fetchImpl = fetch }) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 'loopback');

  // Ortak güvenlik başlıkları. Varsayılan: hiçbir sitenin içine gömülemez.
  app.use((req, res, next) => {
    res.set({
      'Content-Security-Policy': "default-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      'Cache-Control': 'no-store',
    });
    next();
  });

  app.use('/static', express.static(resolve(rootDir, 'public'), { index: false, maxAge: 0 }));

  app.get('/', (req, res) => {
    res.send(page({
      title: 'AsistanX Starter App',
      body: `<main class="box"><h1>AsistanX Starter App</h1>
<p>Bu uygulama AsistanX panelinin içinde açılır. Panelinizde <strong>Uygulamalar → App Store</strong> sayfasından kurup menüden açın.</p></main>`,
    }));
  });

  app.get('/healthz', (req, res) => res.json({ ok: true }));

  /**
   * Giriş noktası: AsistanX paneli bu adresi iframe içinde açar ve adrese
   * ?tenant=<alan adı>&token=<oturum anahtarı> ekler.
   */
  app.get('/app', (req, res) => {
    const session = verifySessionToken(req.query.token, config);

    if (session === null) {
      // Bu sayfa yalnız bir hata iletisidir (veri ve işlem içermez), bu yüzden herhangi bir https
      // sayfanın içinde gösterilebilir. Aksi halde panel, iletiniz yerine tarayıcının boş
      // "bağlanmayı reddetti" çerçevesini gösterir ve sorunun ne olduğu anlaşılmaz.
      res.set('Content-Security-Policy', "default-src 'self'; frame-ancestors https:; base-uri 'none'; form-action 'none'");
      res.status(401).send(page({
        title: 'Oturum doğrulanamadı',
        body: `<main class="box"><h1>Oturum doğrulanamadı</h1>
<p>Bu sayfa yalnız AsistanX panelinin içinden açılabilir. Panelde sayfayı yenileyip yeniden deneyin.</p>
<p class="muted">Geliştiriciyseniz: sunucunuzdaki uygulama kimliği ve gizli anahtarın geliştirici portalındaki uygulamanınkiyle aynı olduğunu denetleyin.</p></main>`,
      }));
      return;
    }

    db.touchInstallation(session.tenantId, session.tenantHost);

    // Yalnız anahtarı imzalanmış müşterinin paneli bu sayfayı içine gömebilir.
    res.set(
      'Content-Security-Policy',
      `default-src 'self'; frame-ancestors ${session.tenantOrigin}; base-uri 'none'; form-action 'self'`,
    );
    res.send(page({
      title: 'Starter App',
      bodyAttrs: ` data-parent-origin="${escapeHtml(session.tenantOrigin)}"`,
      body: `<main class="app">
  <header>
    <h1>Merhaba, <span data-tenant>…</span></h1>
    <p class="muted">Bu sayfa AsistanX panelinizin içinde, kendi sunucusunda çalışan örnek bir uygulamadır.</p>
    <p class="row">
      <button type="button" data-close>Panele dön</button>
      <span class="muted" data-fullscreen-info></span>
    </p>
  </header>

  <nav class="sections" aria-label="Bölümler">
    <a href="#" data-goto="oturum">Oturum</a>
    <a href="#" data-goto="urunler">Ürünler</a>
    <a href="#" data-goto="sorular">Sorular</a>
    <a href="#" data-goto="notlar">Notlar</a>
    <a href="#" data-goto="eposta">E-posta</a>
  </nav>

  <section class="card" data-section="oturum">
    <h2>Oturum</h2>
    <dl class="facts">
      <div><dt>Müşteri</dt><dd data-fact="tenant_host">…</dd></div>
      <div><dt>Müşteri kimliği</dt><dd data-fact="tenant_id">…</dd></div>
      <div><dt>Kullanıcı</dt><dd data-fact="user">…</dd></div>
      <div><dt>Bu kullanıcının yetkileri</dt><dd data-fact="user_scopes">…</dd></div>
      <div><dt>Uygulamanın izinleri</dt><dd data-fact="app_scopes">…</dd></div>
      <div><dt>Arka planda erişim</dt><dd data-fact="offline_access">…</dd></div>
      <div><dt>İlk açılış</dt><dd data-fact="first_seen_at">…</dd></div>
      <div><dt>Anahtar bitişi</dt><dd data-fact="expires">…</dd></div>
    </dl>
  </section>

  <section class="card" data-section="urunler">
    <h2>Ürünleriniz (AsistanX API)</h2>
    <p class="muted" data-products-info>Yükleniyor…</p>
    <ul class="notes" data-products></ul>
  </section>

  <section class="card" data-section="sorular">
    <h2>Cevap bekleyen sorular (AsistanX API)</h2>
    <p class="muted" data-questions-info>Yükleniyor…</p>
    <p class="error" data-questions-error hidden></p>
    <ul class="notes" data-questions></ul>
  </section>

  <section class="card" data-section="notlar">
    <h2>Notlar</h2>
    <p class="muted">Notlar yalnız sizin firmanıza aittir; başka bir AsistanX müşterisi göremez.</p>
    <div class="row">
      <input type="text" data-note-input maxlength="500" placeholder="Bir not yazın" aria-label="Yeni not">
      <button type="button" data-note-add>Ekle</button>
    </div>
    <p class="error" data-error hidden></p>
    <ul class="notes" data-notes></ul>
    <p class="muted" data-empty hidden>Henüz not yok.</p>
    <p class="row">
      <button type="button" data-print>Notları yazdır (A4)</button>
      <span class="muted" data-print-info></span>
    </p>
  </section>

  <section class="card" data-section="eposta">
    <h2>E-posta bildirimi gönder (kendime)</h2>
    <p class="muted">Uygulama, müşterinin panel kullanıcılarına AsistanX üzerinden e-posta bildirimi gönderebilir. Bu örnek yalnız size (oturumdaki kullanıcıya) gönderir. "E-posta bildirimi" izni gerekir.</p>
    <div class="row">
      <input type="text" data-mail-subject maxlength="150" value="Starter App deneme bildirimi" aria-label="Konu">
    </div>
    <div class="row">
      <textarea data-mail-text maxlength="2000" rows="3" aria-label="İleti">Merhaba, bu e-posta Starter App'in e-posta bildirimi örneğidir.</textarea>
    </div>
    <p class="row">
      <button type="button" data-mail-send>Kendime gönder</button>
      <span class="muted" data-mail-info></span>
    </p>
  </section>
</main>
<script src="/static/app.js" defer></script>`,
    }));
  });

  // --- AsistanX olay bildirimleri (webhook). İmza HAM gövde üzerinden doğrulanır. ---
  app.post('/webhooks/asistanx', express.raw({ type: () => true, limit: '64kb' }), createWebhookHandler({ config, db, asistanx, now }));

  // --- AsistanX WhatsApp komutları. İmza HAM gövde üzerinden doğrulanır; yanıt metin, dosya, soru ya da geç yanıt olabilir. ---
  const whatsapp = createWhatsappHandler({ config, db, asistanx, now, fetchImpl });
  app.post('/whatsapp/asistanx', express.raw({ type: () => true, limit: '64kb' }), whatsapp);
  app.get('/whatsapp/files/:key/:name', whatsapp.download);
  app.locals.whatsapp = whatsapp;

  // --- API: her istek oturum anahtarı ister; veri her zaman müşteriye göre süzülür. ---
  const api = express.Router();
  api.use(express.json({ limit: '10kb' }));
  api.use(requireSession(config, db));

  api.get('/me', (req, res) => {
    const { installation, userId, userName, appManager, userScopes, expiresAt } = req.asistanx;
    res.json({
      tenant_id: installation.tenant_id,
      tenant_host: installation.tenant_host,
      user_id: userId,
      user_name: userName,
      app_manager: appManager,
      // Oturum anahtarından: yalnız ekranı çizmek için. Asıl denetim AsistanX API'sinde.
      user_scopes: userScopes,
      first_seen_at: installation.first_seen_at,
      expires_at: expiresAt,
    });
  });

  /**
   * Uygulamanın bu müşterideki bağlantısı: müşteri anahtarı alınabiliyor mu, hangi izinler verilmiş.
   * Veri döndürmez; müşteri anahtarı ekrandaki kişiye veri göstermek için KULLANILMAZ.
   */
  api.get('/connection', async (req, res) => {
    const access = await asistanx.access(req.asistanx.installation);
    res.json(access.ok
      // offline_access: müşteri "arka planda erişim" izni verdi mi. Vermediyse müşteri anahtarı veri
      // uçlarında 403 user_required alır; veri yalnız kullanıcıya bağlı anahtarla (getAsUser) okunur.
      ? { connected: true, scopes: access.scopes, offline_access: access.scopes.includes('arkaplan:read') }
      : { connected: false, error: access.error, message: access.message });
  });

  /**
   * AsistanX API örneği: müşterinin ürünlerinden ilk 10'u. İstek uygulamanın SUNUCUSUNDAN,
   * EKRANDAKİ KULLANICIYA bağlı API anahtarıyla yapılır; anahtar tarayıcıya gitmez.
   * Kullanıcının panelde Ürünler yetkisi yoksa AsistanX user_forbidden döner.
   */
  api.get('/products', async (req, res) => {
    const result = await asistanx.getAsUser(req.asistanx.installation, req.asistanx, 'products', { per_page: 10 });

    if (!result.ok) {
      // no_scopes / insufficient_scope: müşteri uygulamaya ürün izni vermemiş.
      // user_forbidden: bu kullanıcının yetkisi yok. module_disabled: müşteride modül kapalı.
      res.json({ available: false, error: result.error, message: result.message });
      return;
    }

    const rows = Array.isArray(result.data?.data) ? result.data.data : [];
    res.json({
      available: true,
      total: result.data?.pagination?.total ?? rows.length,
      products: rows.map((p) => ({ id: p.id, title: p.title, sku: p.sku, stock: p.stock })),
    });
  });

  /**
   * AsistanX API örneği (okuma): cevap bekleyen müşteri soruları. Pazaryeri ve vitrin soruları
   * aynı kutudadır. "Müşteri soruları: okuma" izni ve kullanıcının panelde soru ekranı yetkisi gerekir.
   */
  api.get('/questions', async (req, res) => {
    const result = await asistanx.getAsUser(req.asistanx.installation, req.asistanx, 'questions', { status: 'NEW', per_page: 10 });

    if (!result.ok) {
      res.json({ available: false, error: result.error, message: result.message });
      return;
    }

    const rows = Array.isArray(result.data?.data) ? result.data.data : [];
    res.json({
      available: true,
      total: result.data?.pagination?.total ?? rows.length,
      questions: rows.map((q) => ({
        id: q.id,
        marketplace: q.marketplace ?? q.service ?? null,
        customer_name: q.customer_name ?? null,
        product_name: q.product_name ?? null,
        last_message: q.last_message ?? null,
        created_at: q.created_at ?? null,
      })),
    });
  });

  /**
   * AsistanX API örneği (YAZMA): soruyu yanıtlar. Yanıt PAZARYERİNE GERÇEKTEN GÖNDERİLİR ve geri
   * alınamaz; bu yüzden yalnız kullanıcının yazıp gönderdiği metinle, kullanıcının anahtarıyla
   * çağrılır. "Müşteri soruları: yazma" izni gerekir.
   */
  api.post('/questions/:id/reply', async (req, res) => {
    const id = Number(req.params.id);
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!Number.isSafeInteger(id) || id <= 0) {
      res.status(404).json({ error: 'not_found', message: 'Soru bulunamadı.' });
      return;
    }
    if (message === '' || message.length > 5000) {
      res.status(422).json({ error: 'invalid_reply', message: 'Yanıt 1 ile 5000 karakter arasında olmalı.' });
      return;
    }

    const result = await asistanx.postAsUser(req.asistanx.installation, req.asistanx, `questions/${id}/reply`, { message });
    if (!result.ok) {
      // Hata kodu olduğu gibi tarayıcıya verilir; ileti orada seçilir (public/app.js questionsMessage).
      res.status(result.status === 404 ? 404 : 502).json({ error: result.error, message: result.message });
      return;
    }
    res.status(201).json({ sent: true, question_id: id });
  });

  /**
   * AsistanX YAZDIRMA örneği: ekrandaki kullanıcının departmanındaki yazıcılar.
   * "Yazdırma: okuma" izni gerekir. Yazıcıyı uygulama seçemez; yalnız kâğıt türünü seçer.
   */
  api.get('/print/printers', async (req, res) => {
    const result = await asistanx.getAsUser(req.asistanx.installation, req.asistanx, 'printing/printers');
    if (!result.ok) {
      res.json({ available: false, error: result.error, message: result.message });
      return;
    }
    const data = result.data?.data ?? {};
    res.json({
      available: true,
      department: data.department?.name ?? null,
      printers: (Array.isArray(data.printers) ? data.printers : []).map((slot) => ({
        paper: slot.paper,
        label: slot.label,
        printer: slot.printer ? slot.printer.name : null,
      })),
    });
  });

  /**
   * AsistanX YAZDIRMA örneği: bu müşterinin notlarını PDF yapar ve yazıcıya gönderir.
   * PDF'i uygulama hazırlar (src/pdf.js) ve içeriğini base64 olarak yollar. Kendi sunucunuzda
   * duran bir dosya için "url" de gönderebilirsiniz; o zaman dosyayı AsistanX indirir.
   * "Yazdırma: yazma" izni ve KULLANICIYA BAĞLI anahtar gerekir: belge o kullanıcının
   * departmanındaki yazıcıdan çıkar. Gerçek kâğıt harcar; yalnız kullanıcının isteğiyle çağrılır.
   */
  api.post('/print/notes', async (req, res) => {
    const paper = req.body?.paper === 'A5' ? 'A5' : 'A4';
    const { installation } = req.asistanx;
    const notes = db.listNotes(installation.id);
    if (notes.length === 0) {
      res.status(422).json({ error: 'no_notes', message: 'Yazdırılacak not yok.' });
      return;
    }

    const pdf = textPdf(
      `Starter App notlari - ${installation.tenant_host}`,
      notes.map((note) => `${String(note.created_at).slice(0, 16).replace('T', ' ')}  ${String(note.body).replace(/\s+/g, ' ')}`),
      paper,
    );

    const result = await asistanx.postAsUser(installation, req.asistanx, 'printing/jobs', {
      paper,
      copies: 1,
      content_base64: pdf.toString('base64'),
    });
    if (!result.ok) {
      res.status(502).json({ error: result.error, message: result.message });
      return;
    }

    const job = result.data?.data ?? {};
    res.status(201).json({ job_id: job.id ?? null, status: job.status ?? 'waiting', printer: job.printer?.name ?? null });
  });

  /** Yazdırma işinin durumu: waiting | printed | expired. */
  api.get('/print/jobs/:id', async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id <= 0) {
      res.status(404).json({ error: 'not_found', message: 'Yazdırma işi bulunamadı.' });
      return;
    }
    const result = await asistanx.getAsUser(req.asistanx.installation, req.asistanx, `printing/jobs/${id}`);
    if (!result.ok) {
      res.status(result.status === 404 ? 404 : 502).json({ error: result.error, message: result.message });
      return;
    }
    res.json({ job_id: id, status: result.data?.data?.status ?? 'waiting' });
  });

  /**
   * AsistanX E-POSTA BİLDİRİMİ örneği: oturumdaki kullanıcıya (yalnız ona) e-posta gönderir.
   * Alıcı tarayıcıdan ALINMAZ: oturum anahtarındaki kullanıcı numarasıdır (sub). Müşteri anahtarıyla
   * gönderilir; "E-posta bildirimi" izni gerekir. Düğme uygulamanın kendi adresine gider (AsistanX
   * yalnız uygulamanın app_url alan adını ya da müşterinin panel alan adını kabul eder).
   */
  api.post('/mail/self', async (req, res) => {
    const subject = typeof req.body?.subject === 'string' ? req.body.subject.trim() : '';
    const text = typeof req.body?.text === 'string' ? req.body.text.trim() : '';
    if (subject === '' || subject.length > 150 || text === '' || text.length > 2000) {
      res.status(422).json({ error: 'invalid_mail', message: 'Konu 1–150, ileti 1–2000 karakter olmalı.' });
      return;
    }
    const userId = Number(req.asistanx.userId);
    if (!Number.isSafeInteger(userId) || userId <= 0) {
      res.status(422).json({ error: 'invalid_mail', message: 'Oturumdaki kullanıcı tanınmadı.' });
      return;
    }

    const appOrigin = config.publicUrl ?? `https://${req.get('host')}`;
    const result = await asistanx.sendMail(req.asistanx.installation, {
      to_user_ids: [userId],
      subject,
      text,
      action: { label: 'Starter App\'i aç', url: `${appOrigin}/` },
      // Her tıklama yeni bildirimdir; ağ hatasında yinelenen istek ikinci e-posta göndermez.
      idempotency_key: `starter-self-${randomUUID()}`,
    });

    if (!result.ok) {
      res.status(result.status === 429 ? 429 : result.status === 422 ? 422 : 502).json({
        error: result.error,
        message: result.message,
        rejected: result.rejected ?? null,
      });
      return;
    }
    res.status(202).json({ id: result.data.id, accepted: result.data.accepted, rejected: result.data.rejected });
  });

  api.get('/notes', (req, res) => {
    res.json({ notes: db.listNotes(req.asistanx.installation.id) });
  });

  api.post('/notes', (req, res) => {
    const body = typeof req.body?.body === 'string' ? req.body.body.trim() : '';
    if (body === '' || body.length > 500) {
      res.status(422).json({ error: 'invalid_note', message: 'Not 1 ile 500 karakter arasında olmalı.' });
      return;
    }
    res.status(201).json({ note: db.addNote(req.asistanx.installation.id, req.asistanx.userId, body) });
  });

  api.delete('/notes/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id <= 0 || !db.deleteNote(req.asistanx.installation.id, id)) {
      res.status(404).json({ error: 'not_found', message: 'Not bulunamadı.' });
      return;
    }
    res.status(204).end();
  });

  app.use('/api', api);

  app.use((req, res) => {
    res.status(404).json({ error: 'not_found' });
  });

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    const status = err.status >= 400 && err.status < 500 ? err.status : 500;
    if (status === 500) {
      console.error(err);
    }
    res.status(status).json({ error: status === 500 ? 'server_error' : 'bad_request' });
  });

  return app;
}
