import { createHmac, timingSafeEqual } from 'node:crypto';

/**
 * AsistanX olay bildirimleri (webhook).
 *
 * AsistanX, müşteri tarafında bir şey olduğunda (kurulum, kaldırma, izin onayı) uygulamanın
 * bildirim adresine imzalı bir POST isteği atar:
 *
 *   X-AsistanX-Event:     app.installed
 *   X-AsistanX-Delivery:  <bildirimin tekil numarası>
 *   X-AsistanX-Timestamp: <saniye cinsinden zaman>
 *   X-AsistanX-Signature: sha256=<HMAC-SHA256(gizli anahtar, "<zaman>.<ham gövde>")>
 *
 *   { "id": "…", "event": "app.installed", "app": "…", "tenant": "…", "dest": "musteri.com",
 *     "occurred_at": "2026-01-01T10:00:00Z", "data": { "scopes": ["urunler:read"] } }
 *
 * Kurallar:
 *  - İmzayı HAM gövde üzerinden doğrulayın (JSON'u çözüp yeniden yazmayın).
 *  - Zaman damgası 5 dakikadan eskiyse reddedin (eski bir isteğin yeniden oynatılmasına karşı).
 *  - Aynı bildirim birden çok kez gelebilir (yeniden deneme); tekil numarasına göre bir kez işleyin.
 *  - Bildirimler sırayla gelmeyebilir; occurred_at değerine bakın (aşağıda app.uninstalled).
 *  - Hızlı yanıt verin (2xx). 5xx ve zaman aşımında AsistanX birkaç kez yeniden dener.
 */

export const TOLERANCE_SECONDS = 300;

export function signWebhook(secret, timestamp, rawBody) {
  return 'sha256=' + createHmac('sha256', secret).update(`${timestamp}.`).update(rawBody).digest('hex');
}

/** İmza ve zaman damgası geçerli mi? rawBody: Buffer ya da string. */
export function verifyWebhook({ secret, timestamp, signature, rawBody, now = Date.now() }) {
  if (typeof timestamp !== 'string' || !/^\d{1,12}$/.test(timestamp) || typeof signature !== 'string') {
    return false;
  }
  if (Math.abs(Math.floor(now / 1000) - Number(timestamp)) > TOLERANCE_SECONDS) {
    return false;
  }
  const expected = Buffer.from(signWebhook(secret, timestamp, rawBody));
  const given = Buffer.from(signature);
  return expected.length === given.length && timingSafeEqual(expected, given);
}

const isHost = (value) => typeof value === 'string' && /^[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?$/i.test(value);

/**
 * Express işleyicisi. Gövde express.raw() ile HAM (Buffer) alınmış olmalıdır.
 */
export function createWebhookHandler({ config, db, asistanx, now = Date.now }) {
  return (req, res) => {
    const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    const valid = verifyWebhook({
      secret: config.clientSecret,
      timestamp: req.get('X-AsistanX-Timestamp'),
      signature: req.get('X-AsistanX-Signature'),
      rawBody,
      now: now(),
    });
    if (!valid) {
      res.status(401).json({ error: 'invalid_signature' });
      return;
    }

    let payload;
    try {
      payload = JSON.parse(rawBody.toString('utf8'));
    } catch {
      res.status(400).json({ error: 'invalid_body' });
      return;
    }

    const { id, event, tenant, dest } = payload ?? {};
    if (typeof id !== 'string' || id === '' || typeof event !== 'string' || typeof tenant !== 'string' || tenant === '' || !isHost(dest)) {
      res.status(400).json({ error: 'invalid_body' });
      return;
    }

    // Aynı bildirim ikinci kez geldiyse (yeniden deneme) bir daha işlenmez.
    if (!db.recordWebhook(id, event, tenant)) {
      res.status(204).end();
      return;
    }

    const scopes = Array.isArray(payload.data?.scopes) ? payload.data.scopes.filter((s) => typeof s === 'string') : null;

    if (event === 'app.installed') {
      // Müşteri uygulamayı kurdu: kaydı aç ve "izin yok" hatırasını sil. Saklı anahtar varsa
      // dokunulmaz: geçersizse ilk API çağrısında 401 gelir ve kendiliğinden yenilenir.
      const installation = db.touchInstallation(tenant, dest);
      asistanx.forget(installation.id, { dropToken: false });
    } else if (event === 'app.uninstalled') {
      // Müşteri kaldırdı: API anahtarı artık geçersiz, sil. Müşterinin verisini (notlar) ne
      // yapacağınız size kalmış; örnek saklar, böylece yeniden kurulumda geri gelir.
      //
      // Bildirimler sırayla gelmeyebilir: müşteri kaldırıp hemen yeniden kurarsa, kaldırma bildirimi
      // siz yeni anahtarı aldıktan SONRA ulaşabilir. Olay, elinizdeki anahtardan eskiyse yok sayın;
      // yoksa yeni kurulumun anahtarını silmiş olursunuz.
      const current = db.findInstallation(tenant);
      const occurredAt = Date.parse(payload.occurred_at);
      const tokenAt = current?.api_token_at ? Date.parse(current.api_token_at) : NaN;
      const stale = Number.isFinite(occurredAt) && Number.isFinite(tokenAt) && tokenAt > occurredAt + 1000;
      if (current && !stale) {
        db.markUninstalled(tenant);
        asistanx.forget(current.id, { dropToken: true });
      }
    } else if (event === 'app.scopes_updated') {
      // Müşteri yeni izinleri onayladı: API anahtarı aynı kalır, yalnız izin listesi değişir.
      const installation = db.findInstallation(tenant);
      if (installation) {
        asistanx.forget(installation.id, { dropToken: false });
        if (scopes) {
          db.setApiScopes(installation.id, scopes);
        }
      }
    }
    // Tanımadığınız olayları yok sayın: ileride yeni olaylar eklenebilir.

    res.status(204).end();
  };
}
