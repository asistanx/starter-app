import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { rootDir } from './paths.js';

// .env varsa yükle (ortam değişkeni zaten tanımlıysa onu ezmez).
const envFile = resolve(rootDir, '.env');
if (existsSync(envFile)) {
  process.loadEnvFile(envFile);
}

function required(name) {
  const value = (process.env[name] ?? '').trim();
  if (value === '' || /x{8,}$/.test(value)) {
    throw new Error(`${name} tanımlı değil. .env.example dosyasını .env olarak kopyalayıp doldurun.`);
  }
  return value;
}

export const config = {
  clientId: required('ASISTANX_CLIENT_ID'),
  clientSecret: required('ASISTANX_CLIENT_SECRET'),
  port: Number(process.env.PORT ?? 5485),
  host: process.env.HOST ?? '127.0.0.1',
  // Uygulamanın dışarıdan erişilen adresi (isteğe bağlı). Boşsa isteğin Host başlığından kurulur.
  publicUrl: (process.env.PUBLIC_URL ?? '').trim().replace(/\/+$/, '') || undefined,
  databaseFile: resolve(rootDir, process.env.DATABASE_FILE ?? './data/app.sqlite'),
};
