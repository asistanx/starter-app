import jwt from 'jsonwebtoken';

const HOST_PATTERN = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/;

/**
 * AsistanX oturum anahtarını doğrular.
 *
 * Oturum anahtarı, AsistanX panelinin uygulamanızın GİZLİ ANAHTARIYLA imzaladığı kısa
 * ömürlü (5 dk) bir JWT'dir (HS256). İmza geçerliyse isteğin gerçekten AsistanX panelinden,
 * anahtarda yazan müşteri ve kullanıcı adına geldiğinden emin olursunuz.
 *
 *   iss     müşteri panelinin adresi   (https://ornek.com)
 *   aud     uygulama kimliğiniz        (client_id) — başka uygulamanın anahtarını reddeder
 *   sub     paneldeki kullanıcının numarası
 *   tenant  müşteri kimliği            dest  müşteri alan adı
 *   user         { id, name, app_manager } — app_manager: uygulama kurup izin verebilen kullanıcı
 *   user_scopes  kullanıcının yetkili olduğu izinler (uygulamanın izinleri ∩ kullanıcının panel yetkisi)
 *
 * user_scopes yalnız ekranı çizmek içindir (kullanıcının göremeyeceği bölümü göstermeyin).
 * Asıl denetimi AsistanX API'si yapar: bkz. asistanx-api.js "kullanıcıya bağlı anahtar".
 *
 * Geçerliyse { tenantId, tenantHost, tenantOrigin, userId, userName, appManager, userScopes,
 * expiresAt } döner; değilse null. userScopes eski panellerde gelmeyebilir (null).
 */
export function verifySessionToken(token, { clientId, clientSecret }) {
  if (typeof token !== 'string' || token === '' || token.length > 4096) {
    return null;
  }

  let claims;
  try {
    claims = jwt.verify(token, clientSecret, {
      algorithms: ['HS256'], // "none" ve açık anahtarlı algoritmalar kabul edilmez
      audience: clientId,
      clockTolerance: 5,
    });
  } catch {
    return null;
  }

  const { tenant, dest, sub, iss, exp } = claims;
  if (typeof tenant !== 'string' || tenant === '' || typeof sub !== 'string' || sub === '') {
    return null;
  }
  if (typeof dest !== 'string' || !HOST_PATTERN.test(dest) || iss !== `https://${dest}`) {
    return null;
  }

  const user = claims.user !== null && typeof claims.user === 'object' ? claims.user : {};

  return {
    tenantId: tenant,
    tenantHost: dest,
    tenantOrigin: `https://${dest}`,
    userId: sub,
    userName: typeof user.name === 'string' ? user.name : '',
    appManager: user.app_manager === true,
    userScopes: Array.isArray(claims.user_scopes) ? claims.user_scopes.filter((scope) => typeof scope === 'string') : null,
    expiresAt: exp,
  };
}

/** "Authorization: Bearer <anahtar>" başlığından anahtarı okur. */
export function bearerToken(req) {
  const header = req.get('authorization') ?? '';
  const match = /^Bearer\s+(\S+)$/i.exec(header);
  return match ? match[1] : null;
}

/**
 * API uçları için ara katman: geçerli oturum anahtarı yoksa 401 döner.
 * Geçerliyse müşteriyi kaydeder/günceller ve req.asistanx'i doldurur.
 *
 * Çerez KULLANILMAZ: uygulama iframe içinde açıldığı için tarayıcılar üçüncü taraf
 * çerezlerini engeller. Her istekte oturum anahtarı başlıkta gönderilir.
 */
export function requireSession(config, db) {
  return (req, res, next) => {
    const token = bearerToken(req);
    const session = verifySessionToken(token, config);
    if (session === null) {
      res.status(401).json({ error: 'invalid_session', message: 'Oturum anahtarı geçersiz ya da süresi dolmuş.' });
      return;
    }

    req.asistanx = {
      ...session,
      // Kullanıcıya bağlı API anahtarı almak için AsistanX'e geri gönderilir; tarayıcıya dönülmez.
      sessionToken: token,
      installation: db.touchInstallation(session.tenantId, session.tenantHost),
    };
    next();
  };
}
