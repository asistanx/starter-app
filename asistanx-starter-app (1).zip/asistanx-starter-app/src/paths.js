import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

/** Proje kök klasörü. */
export const rootDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');
