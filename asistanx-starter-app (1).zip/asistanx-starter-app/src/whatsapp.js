import { verifyWebhook } from './webhooks.js';

/**
 * AsistanX WhatsApp komutları.
 *
 * AsistanX müşterileri WhatsApp'tan yazarak işlerini sorar. Uygulamanız bu asistana kendi
 * komutlarını ekleyebilir (geliştirici portalında "WhatsApp komutları"). Kullanıcının isteği
 * komutunuza uyarsa AsistanX bu adrese imzalı bir istek atar; yanıt metnini siz dönersiniz:
 *
 *   POST /whatsapp/asistanx
 *   X-AsistanX-Event: whatsapp.command        (imza başlıkları olay bildirimleriyle aynıdır)
 *
 *   { "id": "…", "event": "whatsapp.command", "app": "…", "tenant": "…", "dest": "musteri.com",
 *     "data": { "command": "not_ozeti", "params": {}, "message": "kaç notum var",
 *               "sender": { "type": "personnel", "user": { "id": 12, "name": "Ayşe" } },
 *               "session_token": "<oturum anahtarı ya da null>" } }
 *
 *   → 200 { "text": "3 notunuz var." }
 *
 * Yanıt yalnız metin olmak zorunda değildir (bu dosyada her birinin örneği var):
 *   { "text": "…", "media": [ { "url": "https://…", "caption": "…" } ] }        dosya / görsel
 *   { "options": { "question": "…", "items": [ { "label": "…", "params": {…} } ] } }   seçenekli soru
 *   { "text": "soru", "expect_reply": { "param": "metin" }, "state": {…} }      serbest cevap bekleme
 *   { "defer": true, "text": "hazırlıyorum" }  → sonra data.reply.url adresine asıl yanıt     geç yanıt
 *
 * Kurallar:
 *  - İmzayı HAM gövde üzerinden doğrulayın; 5 dakikadan eski isteği reddedin.
 *  - 10 saniye içinde 200 ve geçerli bir yanıt dönün; yoksa kullanıcıya "yanıt vermiyor" yazılır.
 *    İşiniz uzun sürecekse "defer" kullanın.
 *  - params, asistanın istekten çıkardığı değerlerdir; eksik ya da hatalı olabilir, doğrulayın.
 *  - Telefon numarası gelmez. sender.user yalnız soran kişi müşterinin panel kullanıcısıysa doludur.
 *  - Müşterinin verisini okurken session_token ile KULLANICIYA BAĞLI anahtar alın (getAsUser):
 *    kullanıcı panelde göremediği veriyi WhatsApp'tan da göremez.
 *  - Çok adımlı konuşmada her adım AYNI komuta yeni bir istek olarak gelir; aradaki bilgiyi "state"
 *    ile taşıyın. state her yanıtta yeniden yazılır: göndermezseniz silinir.
 *  - Geç yanıtta gizli anahtarınızı YALNIZ müşterinin kendi adresine gönderin (replyUrlFor).
 */

import { randomBytes } from 'node:crypto';

const NOTE_MAX = 500;
const FILE_TTL_MS = 10 * 60 * 1000;

/**
 * Geç yanıt adresi. İstekteki reply.url değerine körü körüne güvenmek yerine adres, imzası
 * doğrulanmış "dest" alanından yeniden kurulur ve gelenle karşılaştırılır: gizli anahtar
 * başka bir sunucuya gönderilemez.
 */
export function replyUrlFor(dest, reply) {
  const expected = `https://${dest}/api/v1/apps/whatsapp/reply`;
  if (reply === null || typeof reply !== 'object' || reply.url !== expected
    || typeof reply.token !== 'string' || !/^axwr_[A-Za-z0-9]{48}$/.test(reply.token)) {
    return null;
  }
  return expected;
}

/** Komut düz metin dönerse { text } yapılır; nesne dönerse olduğu gibi gönderilir. */
const reply = (res, out) => res.status(200).json(typeof out === 'string' ? { text: out } : out);

export function createWhatsappHandler({ config, db, asistanx, now = Date.now, fetchImpl = fetch }) {
  /** Kısa ömürlü indirme adresleri: tahmin edilemeyen anahtar → dosya. Oturum gerektirmez (WhatsApp ağ geçidi indirir). */
  const files = new Map();
  const publish = (name, body, baseUrl) => {
    for (const [key, file] of files) {
      if (file.expires < now()) {
        files.delete(key);
      }
    }
    const key = randomBytes(24).toString('hex');
    files.set(key, { name, body, expires: now() + FILE_TTL_MS });
    return `${baseUrl}/whatsapp/files/${key}/${name}`;
  };

  /** Geç yanıt: asıl yanıtı müşterinin AsistanX adresine gönderir. Anahtar tek kullanımlıktır. */
  async function sendLateReply(url, token, body) {
    const response = await fetchImpl(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ client_id: config.clientId, client_secret: config.clientSecret, reply_token: token, ...body }),
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) {
      console.error(`WhatsApp geç yanıtı teslim edilemedi: ${response.status}`);
    }
    return response.ok;
  }

  const commands = {
    /** Uygulamanın kendi verisi: bu müşterinin notları. AsistanX API'si gerekmez. */
    async not_ozeti({ installation }) {
      const notes = db.listNotes(installation.id);
      if (notes.length === 0) {
        return 'Starter App\'te henüz notunuz yok.';
      }
      const last = notes.slice(0, 3).map((note) => `• ${String(note.body).slice(0, 120)}`).join('\n');
      return `Starter App'te ${notes.length} notunuz var. Son notlar:\n${last}`;
    },

    /** Müşterinin AsistanX verisi: soran kullanıcının yetkisiyle okunur. */
    async urun_sayisi({ installation, data }) {
      const user = data.sender?.user;
      if (typeof data.session_token !== 'string' || !user || !Number.isInteger(user.id)) {
        return 'Bu bilgiyi yalnız panel kullanıcıları sorabilir.';
      }

      const result = await asistanx.getAsUser(
        installation,
        { userId: String(user.id), sessionToken: data.session_token },
        'products',
        { per_page: 1 },
      );

      if (!result.ok) {
        switch (result.error) {
          case 'user_forbidden':
            return 'Ürünleri görme yetkiniz yok. Yetki için yöneticinize başvurun.';
          case 'no_scopes':
          case 'insufficient_scope':
            return 'Bu uygulamaya ürünlerinizi görme izni verilmemiş.';
          case 'module_disabled':
          case 'feature_unavailable':
            return 'Bu hesapta Ürünler bölümü açık değil.';
          default:
            return 'Ürün bilgisine şu anda ulaşılamıyor.';
        }
      }

      const total = result.data?.pagination?.total;
      return Number.isInteger(total) ? `Toplam ${total} ürününüz var.` : 'Ürün sayısı okunamadı.';
    },
    /**
     * ÇOK ADIMLI KONUŞMA: not ekleme.
     *   1. adım: metin yok        → "Notunuz nedir?" (expect_reply: sonraki mesaj params.metin olarak gelir)
     *   2. adım: params.metin     → "Kaydedilsin mi?" (seçenekli soru); metin state içinde taşınır
     *   3. adım: params.onay      → state.metin kaydedilir ya da vazgeçilir; state gönderilmez → silinir
     */
    async not_ekle({ installation, data }) {
      const params = data.params !== null && typeof data.params === 'object' ? data.params : {};
      const state = data.state !== null && typeof data.state === 'object' ? data.state : {};

      if (typeof params.onay === 'string') {
        const body = typeof state.metin === 'string' ? state.metin.trim() : '';
        if (params.onay !== 'evet') {
          return 'Vazgeçildi, not kaydedilmedi.';
        }
        if (body === '') {
          return 'Kaydedilecek not bulunamadı. "Not ekle" diyerek yeniden başlayabilirsiniz.';
        }
        const user = data.sender?.user;
        db.addNote(installation.id, Number.isInteger(user?.id) ? String(user.id) : 'whatsapp', body.slice(0, NOTE_MAX));
        return 'Not kaydedildi.';
      }

      const text = typeof params.metin === 'string' ? params.metin.trim().slice(0, NOTE_MAX) : '';
      if (text === '') {
        return { text: 'Notunuz nedir? Yazın, kaydedeyim.', expect_reply: { param: 'metin' }, state: { adim: 'metin' } };
      }

      return {
        text: `Notunuz:\n${text}`,
        options: {
          question: 'Bu not kaydedilsin mi?',
          items: [
            { label: 'Kaydet', params: { onay: 'evet' } },
            { label: 'Vazgeç', params: { onay: 'hayir' } },
          ],
        },
        state: { adim: 'onay', metin: text },
      };
    },

    /**
     * GEÇ YANIT + DOSYA: not dökümü.
     * İsteğe hemen "defer" ile yanıt verilir; döküm hazırlanınca data.reply.url adresine metin ve
     * dosya gönderilir. Dosya adresi kısa ömürlü ve tahmin edilemezdir.
     */
    async not_dokumu({ installation, data, dest, baseUrl, later }) {
      const url = replyUrlFor(dest, data.reply);
      const notes = db.listNotes(installation.id);
      if (notes.length === 0) {
        return 'Starter App\'te henüz notunuz yok.';
      }
      if (url === null) {
        return 'Not dökümü şu anda gönderilemiyor.';
      }

      later(async () => {
        const body = notes.map((note) => `${note.created_at}  ${String(note.body).replace(/\s+/g, ' ')}`).join('\n') + '\n';
        await sendLateReply(url, data.reply.token, {
          text: `Not dökümünüz hazır: ${notes.length} not.`,
          media: [{ url: publish('notlar.txt', body, baseUrl), caption: 'Starter App notları' }],
        });
      });

      return { defer: true, text: 'Not dökümünüzü hazırlıyorum, birazdan gönderiyorum.' };
    },
  };

  /** Yanıt gönderildikten sonra çalışacak işler (geç yanıt). Testler bitmesini bekleyebilsin diye izlenir. */
  const pending = new Set();
  const later = (job) => {
    const run = new Promise((resolve) => setImmediate(resolve)).then(job).catch((error) => console.error(error));
    pending.add(run);
    run.finally(() => pending.delete(run));
  };

  const handler = async (req, res) => {
    const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    const valid = verifyWebhook({
      secret: config.clientSecret,
      timestamp: req.get('X-AsistanX-Timestamp'),
      signature: req.get('X-AsistanX-Signature'),
      rawBody,
      now: now(),
    });
    if (!valid) {
      res.status(401).json({ error: 'invalid_signature' });
      return;
    }

    let payload;
    try {
      payload = JSON.parse(rawBody.toString('utf8'));
    } catch {
      res.status(400).json({ error: 'invalid_body' });
      return;
    }

    const { event, tenant, dest, data } = payload ?? {};
    const validHost = typeof dest === 'string' && /^[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?$/i.test(dest);
    if (event !== 'whatsapp.command' || typeof tenant !== 'string' || tenant === '' || !validHost
      || data === null || typeof data !== 'object' || typeof data.command !== 'string') {
      res.status(400).json({ error: 'invalid_body' });
      return;
    }

    // Nesnenin kendi anahtarı olmayan adlar (ör. "constructor") komut sayılmaz.
    const run = Object.hasOwn(commands, data.command) ? commands[data.command] : null;
    if (run === null) {
      reply(res, 'Starter App bu isteği tanımıyor.');
      return;
    }

    try {
      const installation = db.touchInstallation(tenant, dest);
      const baseUrl = config.publicUrl ?? `https://${req.get('host')}`;
      reply(res, await run({ installation, data, dest, baseUrl, later }));
    } catch (error) {
      console.error(error);
      reply(res, 'Starter App şu anda yanıt veremiyor.');
    }
  };

  /** GET /whatsapp/files/:key/:name — geç yanıtta gönderilen dosyanın kısa ömürlü indirme adresi. */
  handler.download = (req, res) => {
    const file = files.get(String(req.params.key));
    if (!file || file.expires < now() || file.name !== req.params.name) {
      res.status(404).json({ error: 'not_found' });
      return;
    }
    res.set('Cache-Control', 'no-store');
    res.type('text/plain; charset=utf-8').send(file.body);
  };

  /** Bekleyen geç yanıtlar bitince çözülür (testler için). */
  handler.idle = () => Promise.all([...pending]);

  return handler;
}
