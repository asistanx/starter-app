import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';

/**
 * AsistanX API erişimi.
 *
 * 1) Anahtar alma: uygulamanın SUNUCUSU, müşterinin alan adındaki uca uygulama kimliği ve
 *    gizli anahtarıyla istek atar:
 *
 *      POST https://<müşteri alan adı>/api/v1/apps/token
 *      { "client_id": "…", "client_secret": "…" }
 *      → { "access_token": "axat_…", "scopes": ["urunler:read"], "api_base": "https://…/api/v1/mobile" }
 *
 *    Uygulama o müşteride kurulu ve müşteri izin vermişse anahtar döner. Her istek yeni anahtar
 *    üretir ve öncekini iptal eder; bu yüzden anahtar saklanır, her seferinde istenmez.
 *
 * 2) API çağrısı: `Authorization: Bearer <access_token>` ile api_base altındaki uçlar.
 *    Anahtar yalnız müşterinin verdiği izinlerin kapsadığı uçlarda çalışır.
 *
 * İKİ ANAHTAR TÜRÜ VARDIR:
 *
 *   Müşteri anahtarı (axat_…)   — yukarıdaki. Müşterinin uygulamaya verdiği izinlerin tamamıyla
 *                                 çalışır, süresizdir. ARKA PLAN işleri ve bildirim işleme içindir.
 *
 *   Kullanıcı anahtarı (axut_…) — aynı uca panelden gelen oturum anahtarı da gönderilerek alınır:
 *                                 { client_id, client_secret, session_token }
 *                                 O an ekrandaki kullanıcıya bağlıdır, 1 saat geçerlidir. AsistanX her
 *                                 istekte kullanıcının panel yetkisine de bakar; yetkisi yoksa
 *                                 403 user_forbidden döner. EKRANDAKİ KİŞİYE VERİ GÖSTERİRKEN bunu
 *                                 kullanın; müşteri anahtarıyla gösterirseniz kullanıcının panelde
 *                                 göremediği veriyi ona göstermiş olursunuz.
 *
 * 3) E-posta bildirimi: sendMail() — api_base DIŞINDA, https://<müşteri>/api/v1/apps/mail ucuna
 *    müşteri anahtarıyla. Alıcı yalnız müşterinin panel kullanıcısıdır.
 *
 * Hatalar tek biçimdedir: { "error": "<kod>", "message": "…" }. Kodunuzda `error` alanına bakın.
 *
 * Gizli anahtar ve API anahtarı tarayıcıya ASLA gönderilmez. API anahtarı veritabanında
 * şifreli saklanır.
 */
export function createAsistanxApi({ config, db, fetchImpl = fetch, now = Date.now, refusalTtlMs = 60000 }) {
  const key = createHash('sha256').update('asistanx-starter-app:' + config.clientSecret).digest();

  /*
   * Reddedilen anahtar istekleri (izin yok, kurulu değil, kapalı, istek sınırı) kısa süre
   * hatırlanır. Yoksa her sayfa açılışında yeniden sorulur ve AsistanX'in dakikalık istek
   * sınırına takılınır. Müşteri izin verdikten sonra en geç bu süre kadar beklenir.
   */
  const refusals = new Map();

  /*
   * Kullanıcı anahtarları kısa ömürlüdür ve yalnız bellekte tutulur (yeniden başlatmada yenisi
   * alınır). Anahtar: "<müşteri kaydı>:<kullanıcı numarası>".
   */
  const userTokens = new Map();
  const userRefusals = new Map();
  /** Süren kullanıcı anahtarı istekleri: önbellek anahtarı → Promise. */
  const userRequests = new Map();
  const userKey = (installation, session) => `${installation.id}:${session.userId}`;

  function encrypt(plain) {
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', key, iv);
    const data = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
    return Buffer.concat([iv, cipher.getAuthTag(), data]).toString('base64');
  }

  function decrypt(encoded) {
    try {
      const raw = Buffer.from(encoded, 'base64');
      const decipher = createDecipheriv('aes-256-gcm', key, raw.subarray(0, 12));
      decipher.setAuthTag(raw.subarray(12, 28));
      return Buffer.concat([decipher.update(raw.subarray(28)), decipher.final()]).toString('utf8');
    } catch {
      return null; // gizli anahtar değişmiş ya da kayıt bozulmuş: yeniden alınır
    }
  }

  /** Müşteriden yeni API anahtarı ister ve saklar. */
  async function requestAccess(installation) {
    const refused = refusals.get(installation.id);
    if (refused) {
      if (refused.until > now()) {
        return refused.result;
      }
      refusals.delete(installation.id);
    }

    const response = await fetchImpl(`https://${installation.tenant_host}/api/v1/apps/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ client_id: config.clientId, client_secret: config.clientSecret }),
      signal: AbortSignal.timeout(10000),
    });
    const body = await response.json().catch(() => ({}));

    if (!response.ok || typeof body.access_token !== 'string') {
      db.clearApiAccess(installation.id);
      const result = { ok: false, status: response.status, error: body.error ?? 'token_request_failed', message: body.message ?? null };
      refusals.set(installation.id, { until: now() + refusalTtlMs, result });
      return result;
    }

    const base = typeof body.api_base === 'string' ? body.api_base : `https://${installation.tenant_host}/api/v1/mobile`;
    const scopes = Array.isArray(body.scopes) ? body.scopes : [];
    db.saveApiAccess(installation.id, encrypt(body.access_token), scopes, base);

    return { ok: true, token: body.access_token, scopes, base };
  }

  /** Saklı anahtarı döner; yoksa ya da çözülemiyorsa yenisini ister. */
  async function access(installation) {
    const saved = db.getApiAccess(installation.id);
    if (saved) {
      const token = decrypt(saved.tokenEnc);
      if (token) {
        return { ok: true, token, scopes: saved.scopes, base: saved.base };
      }
    }
    return requestAccess(installation);
  }

  /** Paneldeki kullanıcıya bağlı, kısa ömürlü API anahtarı ister (oturum anahtarını AsistanX'e geri verir). */
  /**
   * Aynı kullanıcı için AYNI ANDA yalnız bir anahtar isteği yapılır. AsistanX her yeni kullanıcı
   * anahtarında öncekini iptal eder: sayfa açılırken paralel giden üç istek ayrı ayrı anahtar
   * isterse birbirlerinin anahtarını geçersiz kılar ve 401 alırlar. Bekleyenler aynı sonucu paylaşır.
   */
  function requestUserAccess(installation, session) {
    const cacheKey = userKey(installation, session);
    const running = userRequests.get(cacheKey);
    if (running) {
      return running;
    }
    const request = fetchUserAccess(installation, session).finally(() => userRequests.delete(cacheKey));
    userRequests.set(cacheKey, request);
    return request;
  }

  /**
   * 401 sonrası yenileme: 401 alan anahtar zaten başka bir istek tarafından yenilenmişse yeni anahtar
   * İSTENMEZ, saklı olan kullanılır (yoksa az önce alınan anahtar da iptal edilirdi).
   */
  function renewUserAccess(installation, session, staleToken) {
    const saved = userTokens.get(userKey(installation, session));
    if (saved && saved.token !== staleToken && saved.expiresAt > now()) {
      return Promise.resolve({ ok: true, ...saved });
    }
    return requestUserAccess(installation, session);
  }

  async function fetchUserAccess(installation, session) {
    const cacheKey = userKey(installation, session);
    userTokens.delete(cacheKey);

    const refused = userRefusals.get(cacheKey);
    if (refused) {
      if (refused.until > now()) {
        return refused.result;
      }
      userRefusals.delete(cacheKey);
    }

    const response = await fetchImpl(`https://${installation.tenant_host}/api/v1/apps/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ client_id: config.clientId, client_secret: config.clientSecret, session_token: session.sessionToken }),
      signal: AbortSignal.timeout(10000),
    });
    const body = await response.json().catch(() => ({}));

    if (!response.ok || typeof body.access_token !== 'string') {
      const result = { ok: false, status: response.status, error: body.error ?? 'token_request_failed', message: body.message ?? null };
      // Oturum anahtarının süresi dolmuşsa (401) hatırlama: tarayıcı yenisini gönderince hemen denenir.
      if (response.status !== 401) {
        userRefusals.set(cacheKey, { until: now() + refusalTtlMs, result });
      }
      return result;
    }

    const lifetimeMs = (Number.isFinite(body.expires_in) ? body.expires_in : 3600) * 1000;
    const entry = {
      token: body.access_token,
      scopes: Array.isArray(body.scopes) ? body.scopes : [],
      base: typeof body.api_base === 'string' ? body.api_base : `https://${installation.tenant_host}/api/v1/mobile`,
      // Süre dolmadan bir dakika önce yenile.
      expiresAt: now() + Math.max(lifetimeMs - 60000, 0),
    };
    userTokens.set(cacheKey, entry);

    return { ok: true, ...entry };
  }

  /** Kullanıcının geçerli anahtarını döner; yoksa ya da süresi dolmak üzereyse yenisini ister. */
  async function userAccess(installation, session) {
    const saved = userTokens.get(userKey(installation, session));
    if (saved && saved.expiresAt > now()) {
      return { ok: true, ...saved };
    }
    return requestUserAccess(installation, session);
  }

  async function request(token, base, path, { query = {}, method = 'GET', body } = {}) {
    const url = new URL(base.replace(/\/$/, '') + '/' + path.replace(/^\//, ''));
    for (const [name, value] of Object.entries(query)) {
      url.searchParams.set(name, String(value));
    }
    return fetchImpl(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json',
        ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.timeout(15000),
    });
  }

  /**
   * Anahtarı alır, çağırır; 401'de bir kez yenisini alıp yeniden dener. 401 "istek işlenmedi"
   * demektir, bu yüzden yazma isteğini yinelemek de güvenlidir. Başka hatada yazma YİNELENMEZ.
   */
  async function read(acquire, renew, path, options) {
    let current = await acquire();
    if (!current.ok) {
      return current;
    }

    let response = await request(current.token, current.base, path, options);
    if (response.status === 401) {
      current = await renew(current.token);
      if (!current.ok) {
        return current;
      }
      response = await request(current.token, current.base, path, options);
    }

    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      return { ok: false, status: response.status, error: body.error ?? 'api_error', message: body.message ?? null, errors: body.errors ?? null };
    }

    return { ok: true, data: body };
  }

  /**
   * MÜŞTERİ anahtarıyla okuma: arka plan işleri ve bildirim işleme için. Ekrandaki kişiye veri
   * göstermek için getAsUser kullanın.
   *
   * @returns {{ ok: true, data: any } | { ok: false, status: number, error: string, message: ?string }}
   */
  async function get(installation, path, query = {}) {
    return read(() => access(installation), () => requestAccess(installation), path, { query });
  }

  /**
   * KULLANICI anahtarıyla okuma: AsistanX, uygulamanın izninin yanında ekrandaki kullanıcının
   * panel yetkisine de bakar. Kullanıcı yetkili değilse { ok: false, error: 'user_forbidden' } döner.
   *
   * @param session  requireSession'ın doldurduğu req.asistanx (userId ve sessionToken gerekir)
   */
  async function getAsUser(installation, session, path, query = {}) {
    return read(() => userAccess(installation, session), (stale) => renewUserAccess(installation, session, stale), path, { query });
  }

  /**
   * KULLANICI anahtarıyla YAZMA (POST). Uygulamanın o alanda yazma izni (ör. sorular:write) ve
   * kullanıcının panelde o sayfada yetkisi olmalıdır. Yazma uçları gerçek işlem yapar
   * (ör. soru yanıtı pazaryerine gönderilir): kullanıcının açık isteği olmadan çağırmayın.
   */
  async function postAsUser(installation, session, path, body = {}) {
    return read(() => userAccess(installation, session), (stale) => renewUserAccess(installation, session, stale), path, { method: 'POST', body });
  }

  /**
   * E-POSTA BİLDİRİMİ: müşterinin panel kullanıcılarına uygulamanız adına e-posta gönderir.
   *
   *   POST https://<müşteri alan adı>/api/v1/apps/mail   (Bearer müşteri anahtarı)
   *   { to_user_ids: [12], subject, text | html, action?: { label, url }, idempotency_key? }
   *   → 202 { id, accepted: [12], rejected: [{ user_id, reason }] }
   *
   * "E-posta bildirimi" izni (eposta:read) gerekir; yoksa 403 insufficient_scope. Alıcı YALNIZ
   * müşterinin panel kullanıcısıdır (users.id; oturum anahtarındaki `sub`), e-posta adresi verilemez.
   * Arka planda erişim izni gerekmez: müşteri anahtarıyla, arka plan işinden de gönderilebilir.
   *
   * idempotency_key verin: 401 sonrası istek bir kez yinelenir; aynı anahtar AsistanX'te 24 saat
   * içinde ikinci e-postayı engeller. Başka hatada istek YİNELENMEZ.
   *
   * @returns {{ ok: true, data: { id: string, accepted: number[], rejected: Array<{user_id: number, reason: string}>, duplicate?: boolean } }
   *         | { ok: false, status: number, error: string, message: ?string, errors: ?object, rejected: ?Array, limit?: number, remaining?: number }}
   */
  async function sendMail(installation, message) {
    const mailBase = `https://${installation.tenant_host}/api/v1/apps`;
    const options = { method: 'POST', body: message };

    let current = await access(installation);
    if (!current.ok) {
      return current;
    }
    let response = await request(current.token, mailBase, 'mail', options);
    if (response.status === 401) {
      current = await requestAccess(installation);
      if (!current.ok) {
        return current;
      }
      response = await request(current.token, mailBase, 'mail', options);
    }

    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      return {
        ok: false,
        status: response.status,
        error: body.error ?? 'api_error',
        message: body.message ?? null,
        errors: body.errors ?? null,
        rejected: Array.isArray(body.rejected) ? body.rejected : null,
        ...(Number.isFinite(body.limit) ? { limit: body.limit, remaining: body.remaining } : {}),
      };
    }

    return { ok: true, data: body };
  }

  /**
   * Müşterinin durumu değişti (bildirim geldi): "reddedildi" hatırasını sil; dropToken ise saklı
   * API anahtarını da sil (kurulum/kaldırma sonrası eski anahtar geçersizdir).
   */
  function forget(installationId, { dropToken = false } = {}) {
    refusals.delete(installationId);
    // Kullanıcı anahtarları ve retleri de: izin ya da kurulum değişmiş olabilir.
    for (const map of [userTokens, userRefusals]) {
      for (const cacheKey of map.keys()) {
        if (cacheKey.startsWith(`${installationId}:`)) {
          map.delete(cacheKey);
        }
      }
    }
    if (dropToken) {
      db.clearApiAccess(installationId);
    }
  }

  return { get, getAsUser, postAsUser, sendMail, access, forget };
}
