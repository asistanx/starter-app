/**
 * Bağımlılıksız, tek sayfalık en küçük PDF üreticisi: yalnız örnek için.
 *
 * AsistanX yazdırma ucu hazır bir PDF ister; PDF'i uygulamanız hazırlar. Gerçek bir uygulamada
 * bir PDF kütüphanesi (pdfkit, puppeteer vb.) kullanın: bu üretici yalnız yerleşik Helvetica
 * yazı tipini bilir, Türkçe'ye özgü harfleri (ğ, ş, ı, İ) en yakın Latin harfe çevirir ve
 * sayfaya sığmayan satırları atar.
 */

const PAGE = { A4: [595, 842], A5: [420, 595] };
const TR = { ğ: 'g', Ğ: 'G', ş: 's', Ş: 'S', ı: 'i', İ: 'I', ç: 'c', Ç: 'C', ö: 'o', Ö: 'O', ü: 'u', Ü: 'U' };

function pdfText(value) {
  return String(value)
    .replace(/[ğĞşŞıİçÇöÖüÜ]/g, (ch) => TR[ch])
    .replace(/[^\x20-\x7e]/g, '?')
    .replace(/[\\()]/g, (ch) => `\\${ch}`);
}

/** @returns {Buffer} tek sayfalık PDF */
export function textPdf(title, lines, paper = 'A4') {
  const [width, height] = PAGE[paper] ?? PAGE.A4;
  const maxLines = Math.floor((height - 110) / 16);
  const maxChars = Math.floor((width - 80) / 5.5);
  const shown = lines.slice(0, maxLines).map((line) => String(line).slice(0, maxChars));

  const content = [
    'BT',
    '/F1 15 Tf',
    `40 ${height - 55} Td`,
    `(${pdfText(title)}) Tj`,
    '/F1 10 Tf',
    '0 -28 Td',
    ...shown.flatMap((line) => [`(${pdfText(line)}) Tj`, '0 -16 Td']),
    'ET',
  ].join('\n');

  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${width} ${height}] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>`,
    `<< /Length ${Buffer.byteLength(content, 'latin1')} >>\nstream\n${content}\nendstream`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
  ];

  let out = '%PDF-1.4\n';
  const offsets = [];
  objects.forEach((body, index) => {
    offsets.push(Buffer.byteLength(out, 'latin1'));
    out += `${index + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xref = Buffer.byteLength(out, 'latin1');
  out += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  out += offsets.map((offset) => `${String(offset).padStart(10, '0')} 00000 n \n`).join('');
  out += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;

  return Buffer.from(out, 'latin1');
}
