import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { DatabaseSync } from 'node:sqlite';

/**
 * Çok müşterili (multi-tenant) veri modeli.
 *
 * installations — uygulamayı kullanan her AsistanX müşterisi için bir satır.
 * notes         — örnek veri. HER satır bir installation_id taşır ve HER sorgu
 *                 installation_id ile süzülür; bir müşteri başka müşterinin verisini göremez.
 *
 * Kendi tablolarınızı eklerken aynı kuralı izleyin: installation_id sütunu + her sorguda süzme.
 */
export function openDatabase(file) {
  if (file !== ':memory:') {
    mkdirSync(dirname(file), { recursive: true });
  }

  const db = new DatabaseSync(file);
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000; -- başka bir süreç yazarken hata vermek yerine 5 sn bekle

    CREATE TABLE IF NOT EXISTS installations (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      tenant_id     TEXT NOT NULL UNIQUE,
      tenant_host   TEXT NOT NULL,
      first_seen_at TEXT NOT NULL,
      last_seen_at  TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notes (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      installation_id INTEGER NOT NULL REFERENCES installations(id) ON DELETE CASCADE,
      user_id         TEXT NOT NULL,
      body            TEXT NOT NULL,
      created_at      TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS notes_installation ON notes (installation_id, id);
  `);

  // AsistanX API anahtarı (şifreli) ve müşterinin verdiği izinler, kurulum satırında tutulur.
  const columns = new Set(db.prepare('PRAGMA table_info(installations)').all().map((c) => c.name));
  for (const column of ['api_token_enc', 'api_scopes', 'api_base', 'api_token_at', 'uninstalled_at']) {
    if (!columns.has(column)) {
      db.exec(`ALTER TABLE installations ADD COLUMN ${column} TEXT`);
    }
  }

  // İşlenen bildirimler (webhook): aynı bildirim yeniden gelirse ikinci kez işlenmez.
  db.exec(`
    CREATE TABLE IF NOT EXISTS webhook_events (
      delivery_id TEXT PRIMARY KEY,
      event       TEXT NOT NULL,
      tenant_id   TEXT NOT NULL,
      received_at TEXT NOT NULL
    );
  `);
  const insertWebhook = db.prepare(
    'INSERT OR IGNORE INTO webhook_events (delivery_id, event, tenant_id, received_at) VALUES (?, ?, ?, ?)',
  );
  const findInstallation = db.prepare(
    'SELECT id, tenant_id, tenant_host, first_seen_at, last_seen_at, uninstalled_at, api_token_at FROM installations WHERE tenant_id = ?',
  );
  const markUninstalled = db.prepare('UPDATE installations SET uninstalled_at = ? WHERE tenant_id = ?');
  const setScopes = db.prepare('UPDATE installations SET api_scopes = ? WHERE id = ? AND api_token_enc IS NOT NULL');

  const getApi = db.prepare('SELECT api_token_enc, api_scopes, api_base FROM installations WHERE id = ?');
  const setApi = db.prepare(
    'UPDATE installations SET api_token_enc = ?, api_scopes = ?, api_base = ?, api_token_at = ? WHERE id = ?',
  );

  const upsertInstallation = db.prepare(`
    INSERT INTO installations (tenant_id, tenant_host, first_seen_at, last_seen_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT (tenant_id) DO UPDATE SET tenant_host = excluded.tenant_host, last_seen_at = excluded.last_seen_at,
      uninstalled_at = NULL
    RETURNING id, tenant_id, tenant_host, first_seen_at, last_seen_at
  `);
  const listNotes = db.prepare(
    'SELECT id, user_id, body, created_at FROM notes WHERE installation_id = ? ORDER BY id DESC LIMIT 100',
  );
  const insertNote = db.prepare(
    'INSERT INTO notes (installation_id, user_id, body, created_at) VALUES (?, ?, ?, ?) RETURNING id, user_id, body, created_at',
  );
  const deleteNote = db.prepare('DELETE FROM notes WHERE id = ? AND installation_id = ?');

  return {
    /** Müşteriyi ilk görüşte kaydeder, sonraki görüşlerde günceller. */
    touchInstallation(tenantId, tenantHost) {
      const now = new Date().toISOString();
      return upsertInstallation.get(tenantId, tenantHost, now, now);
    },
    /** Kayıtlı API erişimi: { tokenEnc, scopes, base } ya da anahtar yoksa null. */
    getApiAccess(installationId) {
      const row = getApi.get(installationId);
      if (!row || !row.api_token_enc) {
        return null;
      }
      return { tokenEnc: row.api_token_enc, scopes: JSON.parse(row.api_scopes ?? '[]'), base: row.api_base };
    },
    saveApiAccess(installationId, tokenEnc, scopes, base) {
      // api_token_at: anahtarın alındığı an. Geç gelen eski bir kaldırma bildirimini ayırt etmeye yarar.
      setApi.run(tokenEnc, JSON.stringify(scopes), base, new Date().toISOString(), installationId);
    },
    clearApiAccess(installationId) {
      setApi.run(null, null, null, null, installationId);
    },
    /** Bildirimi kaydeder; daha önce işlenmişse false döner. */
    recordWebhook(deliveryId, event, tenantId) {
      return insertWebhook.run(deliveryId, event, tenantId, new Date().toISOString()).changes > 0;
    },
    findInstallation(tenantId) {
      return findInstallation.get(tenantId) ?? null;
    },
    /** Müşteri uygulamayı kaldırdı. Kayıt yoksa null döner. */
    markUninstalled(tenantId) {
      markUninstalled.run(new Date().toISOString(), tenantId);
      return findInstallation.get(tenantId) ?? null;
    },
    setApiScopes(installationId, scopes) {
      setScopes.run(JSON.stringify(scopes), installationId);
    },
    listNotes(installationId) {
      return listNotes.all(installationId);
    },
    addNote(installationId, userId, body) {
      return insertNote.get(installationId, userId, body, new Date().toISOString());
    },
    deleteNote(installationId, noteId) {
      return deleteNote.run(noteId, installationId).changes > 0;
    },
    close() {
      db.close();
    },
  };
}
