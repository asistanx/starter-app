import { createApp } from './app.js';
import { createAsistanxApi } from './asistanx-api.js';
import { config } from './config.js';
import { openDatabase } from './db.js';

const db = openDatabase(config.databaseFile);
const asistanx = createAsistanxApi({ config, db });
const app = createApp({ config, db, asistanx });

const server = app.listen(config.port, config.host, () => {
  console.log(`AsistanX Starter App http://${config.host}:${config.port} adresinde çalışıyor`);
});

function shutdown() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
