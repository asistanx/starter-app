import assert from 'node:assert/strict';
import { after, before, test } from 'node:test';
import jwt from 'jsonwebtoken';
import { createApp } from '../src/app.js';
import { createAsistanxApi } from '../src/asistanx-api.js';
import { openDatabase } from '../src/db.js';
import { signWebhook } from '../src/webhooks.js';

const config = { clientId: 'axapp_test', clientSecret: 'axsec_' + 'k'.repeat(48) };
const db = openDatabase(':memory:');
let server;
let app;
let base;

function sign(overrides = {}, secret = config.clientSecret, options = {}) {
  const now = Math.floor(Date.now() / 1000);
  const dest = overrides.dest ?? 'firma-a.example';
  return jwt.sign(
    { iss: `https://${dest}`, aud: config.clientId, sub: '7', tenant: 'firma-a', dest, iat: now, nbf: now, exp: now + 300, ...overrides },
    secret,
    { algorithm: 'HS256', ...options },
  );
}

const call = (path, token, init = {}) =>
  fetch(base + path, {
    ...init,
    headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(init.body ? { 'Content-Type': 'application/json' } : {}) },
  });

// AsistanX'i taklit eden sahte ağ: firma-a ürün izni vermiş, firma-b vermemiş.
// Kullanıcılar: 7 ürünleri görebilir; 9'un panelde Ürünler yetkisi yok; 13 uygulamayı açamaz.
const upstream = { tokenRequests: 0, validToken: null, userTokenRequests: 0, userTokens: new Map(), calls: [], tenantScopes: ['urunler:read'], lateReplies: [], questionReplies: [], questionWrite: true, printJobs: [], mails: [], mailIds: new Map() };
let asistanx;
const clock = { offset: 0 };
async function fakeFetch(url, init = {}) {
  const u = new URL(url);
  upstream.calls.push(`${init.method ?? 'GET'} ${u.host}${u.pathname}`);
  const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

  if (u.pathname === '/api/v1/apps/token') {
    const body = JSON.parse(init.body);
    if (body.client_id !== config.clientId || body.client_secret !== config.clientSecret) {
      return json(401, { error: 'invalid_client' });
    }
    if (u.host !== 'firma-a.example') {
      return json(403, { error: 'no_scopes', message: 'İzin yok.' });
    }
    if ('session_token' in body) {
      // Kullanıcıya bağlı anahtar: oturum anahtarı AsistanX'te yeniden doğrulanır.
      let claims;
      try {
        claims = jwt.verify(body.session_token, config.clientSecret, { algorithms: ['HS256'], audience: config.clientId });
      } catch {
        return json(401, { error: 'invalid_session_token', message: 'Oturum anahtarı geçersiz.' });
      }
      if (claims.sub === '13') {
        return json(403, { error: 'user_forbidden', message: 'Bu kullanıcının uygulamayı kullanma yetkisi yok.' });
      }
      upstream.userTokenRequests += 1;
      if (upstream.revokeOld) {
        for (const [saved, sub] of upstream.userTokens) {
          if (sub === claims.sub) {
            upstream.userTokens.delete(saved);
          }
        }
        await new Promise((resolve) => setTimeout(resolve, 5));
      }
      const token = `axut_test_${claims.sub}_${upstream.userTokenRequests}`;
      upstream.userTokens.set(token, claims.sub);
      return json(200, {
        access_token: token, access_mode: 'user', expires_in: 3600, scopes: claims.sub === '9' ? [] : ['urunler:read'],
        user: { id: Number(claims.sub), name: `Kullanıcı ${claims.sub}` }, api_base: `https://${u.host}/api/v1/mobile`,
      });
    }
    upstream.tokenRequests += 1;
    upstream.validToken = `axat_test_${upstream.tokenRequests}`;
    return json(200, { access_token: upstream.validToken, scopes: upstream.tenantScopes, offline_access: upstream.tenantScopes.includes('arkaplan:read'), api_base: `https://${u.host}/api/v1/mobile` });
  }
  if (u.pathname === '/api/v1/mobile/products') {
    const bearer = String(init.headers.Authorization ?? '').replace(/^Bearer /, '');
    if (upstream.userTokens.has(bearer)) {
      if (upstream.userTokens.get(bearer) === '9') {
        return json(403, { error: 'user_forbidden', message: 'Bu işlem için yetkiniz yok. Yetki için yöneticinize başvurun.' });
      }
    } else if (bearer !== upstream.validToken) {
      return json(401, { error: 'invalid_token', message: 'API anahtarı geçersiz ya da süresi dolmuş. Yeni anahtar alın.' });
    }
    return json(200, { status: 'success', data: [{ id: 1, title: 'Deneme ürünü', sku: 'D-1', stock: 4, price: { secret: 1 } }], pagination: { total: 37 } });
  }
  if (u.pathname.startsWith('/api/v1/mobile/printing/')) {
    const bearer = String(init.headers.Authorization ?? '').replace(/^Bearer /, '');
    if (!upstream.userTokens.has(bearer)) {
      // Müşteri (arka plan) anahtarıyla yazdırılamaz.
      return bearer === upstream.validToken
        ? json(403, { error: 'user_required', message: 'Yazdırma, kullanıcıya bağlı anahtarla yapılır.' })
        : json(401, { error: 'invalid_token', message: 'API anahtarı geçersiz.' });
    }
    const user = upstream.userTokens.get(bearer);
    if (u.pathname.endsWith('/printers')) {
      return json(200, { status: 'success', data: {
        department: user === '9' ? null : { id: 1, name: 'Depo' },
        printers: [
          { paper: 'A4', label: 'A4', printer: user === '9' ? null : { id: 11, name: 'HP A4', computer: 'Depo PC', computer_status: 'online' } },
          { paper: 'A5', label: 'A5', printer: null },
          { paper: 'barcode', label: 'Barkod (etiket)', printer: null },
        ],
        limits: { max_bytes: 10485760, max_copies: 20, queue_minutes: 30 },
      } });
    }
    if (u.pathname.endsWith('/jobs') && init.method === 'POST') {
      const body = JSON.parse(init.body);
      if (user === '9') {
        return json(422, { error: 'no_printer', message: 'Kullanıcı bir departmana bağlı değil; yazıcı bulunamadı.' });
      }
      upstream.printJobs.push({ user, body });
      return json(201, { status: 'success', data: { id: 4812, status: 'waiting', copies: body.copies, printer: { id: 11, name: 'HP A4' } } });
    }
    if (u.pathname.endsWith('/jobs/4812')) {
      return json(200, { status: 'success', data: { id: 4812, status: upstream.printJobs.length ? 'printed' : 'waiting' } });
    }
    return json(404, { error: 'not_found', message: 'Yazdırma işi bulunamadı.' });
  }
  const questionMatch = u.pathname.match(/^\/api\/v1\/mobile\/questions(?:\/(\d+)\/reply)?$/);
  if (questionMatch) {
    const bearer = String(init.headers.Authorization ?? '').replace(/^Bearer /, '');
    if (!upstream.userTokens.has(bearer)) {
      return json(401, { error: 'invalid_token', message: 'API anahtarı geçersiz.' });
    }
    if (upstream.userTokens.get(bearer) === '9') {
      return json(403, { error: 'user_forbidden', message: 'Bu işlem için yetkiniz yok.' });
    }
    if (questionMatch[1] === undefined) {
      return json(200, {
        status: 'success',
        data: [{ id: 45, service: 'trendyol', marketplace: 'Trendyol Mağazam', status: 'NEW', customer_name: 'A*** B***', product_name: 'Deneme ürünü', last_message: 'Kargo kaç günde gelir?', created_at: '2026-01-01T10:00:00+03:00', internal: 'gizli' }],
        pagination: { total: 3 },
      });
    }
    if (questionMatch[1] !== '45') {
      return json(404, { error: 'not_found', message: 'Soru bulunamadı.' });
    }
    if (!upstream.questionWrite) {
      return json(403, { error: 'insufficient_scope', message: 'Bu işlem için gereken izin yok.' });
    }
    upstream.questionReplies.push({ method: init.method, body: JSON.parse(init.body), user: upstream.userTokens.get(bearer) });
    return json(200, { status: 'success', data: { line_id: 1, question_id: 45 } });
  }
  if (u.pathname === '/api/v1/apps/mail') {
    // E-posta bildirimi: müşteri anahtarıyla, "eposta:read" izniyle. Alıcı yalnız panel kullanıcısı.
    const bearer = String(init.headers.Authorization ?? '').replace(/^Bearer /, '');
    if (bearer !== upstream.validToken) {
      return json(401, { error: 'invalid_token', message: 'API anahtarı geçersiz.' });
    }
    if (!upstream.tenantScopes.includes('eposta:read')) {
      return json(403, { error: 'insufficient_scope', message: 'Bu işlem için "eposta:read" izni gerekli; müşteri bu izni vermemiş.' });
    }
    const body = JSON.parse(init.body);
    if (body.idempotency_key && upstream.mailIds.has(body.idempotency_key)) {
      return json(202, { ...upstream.mailIds.get(body.idempotency_key), duplicate: true });
    }
    upstream.mails.push({ host: u.host, body });
    const accepted = body.to_user_ids.filter((id) => id !== 13);
    const rejected = body.to_user_ids.filter((id) => id === 13).map((id) => ({ user_id: id, reason: 'no_app_access' }));
    if (accepted.length === 0) {
      return json(422, { error: 'no_valid_recipients', message: 'Alıcıların hiçbirine e-posta gönderilemez.', rejected });
    }
    const result = { id: `mail-${upstream.mails.length}`, accepted, rejected };
    if (body.idempotency_key) {
      upstream.mailIds.set(body.idempotency_key, result);
    }
    return json(202, result);
  }
  if (u.pathname === '/api/v1/apps/whatsapp/reply') {
    const body = JSON.parse(init.body);
    upstream.lateReplies.push({ host: u.host, body });
    if (body.client_id !== config.clientId || body.client_secret !== config.clientSecret) {
      return json(401, { error: 'invalid_client' });
    }
    return json(200, { delivered: true });
  }
  return json(404, {});
}

before(async () => {
  asistanx = createAsistanxApi({ config, db, fetchImpl: fakeFetch, now: () => Date.now() + clock.offset });
  app = createApp({ config, db, asistanx, fetchImpl: fakeFetch });
  server = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  server.close();
  db.close();
});

test('giriş sayfası geçerli anahtarla açılır ve yalnız o müşterinin paneline gömülebilir', async () => {
  const res = await fetch(`${base}/app?tenant=firma-a.example&token=${sign()}`);
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-security-policy'), /frame-ancestors https:\/\/firma-a\.example;/);
  assert.match(await res.text(), /data-parent-origin="https:\/\/firma-a\.example"/);
});

test('anahtarsız ya da geçersiz anahtarla giriş sayfası 401 döner; yalnız hata iletisi gösterir', async () => {
  for (const url of ['/app', '/app?token=abc', `/app?token=${sign({}, 'axsec_' + 'z'.repeat(48))}`]) {
    const res = await fetch(base + url);
    assert.equal(res.status, 401, url);
    // Hata sayfası panel içinde görünebilmeli (veri içermez); uygulamanın kendisi sızmamalı.
    assert.match(res.headers.get('content-security-policy'), /frame-ancestors https:;/);
    const html = await res.text();
    assert.match(html, /Oturum doğrulanamadı/);
    assert.doesNotMatch(html, /data-parent-origin|static\/app\.js/);
  }
});

test('API geçersiz anahtarları reddeder', async () => {
  const now = Math.floor(Date.now() / 1000);
  const bad = {
    'anahtar yok': null,
    'yanlış gizli anahtar': sign({}, 'axsec_' + 'z'.repeat(48)),
    'süresi dolmuş': sign({ iat: now - 600, nbf: now - 600, exp: now - 300 }),
    'başka uygulamanın anahtarı': sign({ aud: 'axapp_baska' }),
    'iss ile dest uyuşmuyor': sign({ iss: 'https://kotu.example' }),
    'müşteri kimliği yok': sign({ tenant: '' }),
    'imzasız (alg none)': jwt.sign({ aud: config.clientId, sub: '7', tenant: 'firma-a', dest: 'firma-a.example', iss: 'https://firma-a.example' }, '', { algorithm: 'none' }),
  };
  for (const [name, token] of Object.entries(bad)) {
    const res = await call('/api/me', token);
    assert.equal(res.status, 401, name);
  }
});

test('müşteriler birbirinin verisini göremez ve silemez', async () => {
  const a = sign();
  const b = sign({ tenant: 'firma-b', dest: 'firma-b.example', sub: '3' });

  const created = await call('/api/notes', a, { method: 'POST', body: JSON.stringify({ body: 'A firmasının notu <b>x</b>' }) });
  assert.equal(created.status, 201);
  const { note } = await created.json();

  const listA = await (await call('/api/notes', a)).json();
  const listB = await (await call('/api/notes', b)).json();
  assert.equal(listA.notes.length, 1);
  assert.equal(listA.notes[0].body, 'A firmasının notu <b>x</b>');
  assert.equal(listB.notes.length, 0);

  assert.equal((await call(`/api/notes/${note.id}`, b, { method: 'DELETE' })).status, 404);
  assert.equal((await (await call('/api/notes', a)).json()).notes.length, 1);
  assert.equal((await call(`/api/notes/${note.id}`, a, { method: 'DELETE' })).status, 204);

  const me = await (await call('/api/me', b)).json();
  assert.equal(me.tenant_id, 'firma-b');
  assert.equal(me.tenant_host, 'firma-b.example');
  assert.equal(me.user_id, '3');
});

test('boş ve çok uzun not reddedilir', async () => {
  const token = sign();
  for (const body of ['', '   ', 'x'.repeat(501)]) {
    const res = await call('/api/notes', token, { method: 'POST', body: JSON.stringify({ body }) });
    assert.equal(res.status, 422);
  }
});

test('ürünler KULLANICIYA bağlı anahtarla okunur; anahtar yeniden kullanılır, iptal edilince yenilenir, tarayıcıya gitmez', async () => {
  const a = sign();

  const first = await (await call('/api/products', a)).json();
  assert.deepEqual(first, { available: true, total: 37, products: [{ id: 1, title: 'Deneme ürünü', sku: 'D-1', stock: 4 }] });
  assert.equal(upstream.userTokenRequests, 1);
  assert.equal(upstream.tokenRequests, 0, 'ekrandaki kişiye veri gösterirken müşteri anahtarı kullanılmamalı');

  await call('/api/products', a);
  assert.equal(upstream.userTokenRequests, 1, 'geçerli kullanıcı anahtarı yeniden kullanılmalı');

  upstream.userTokens.clear(); // anahtar AsistanX tarafında iptal edildi
  const again = await (await call('/api/products', a)).json();
  assert.equal(again.available, true);
  assert.equal(upstream.userTokenRequests, 2, '401 sonrası yeni kullanıcı anahtarı alınmalı');

  assert.doesNotMatch(JSON.stringify([first, again]), /axat_|axut_|axsec_/);
});

test('her kullanıcının kendi anahtarı vardır; panelde yetkisi olmayan kullanıcı ürünleri göremez', async () => {
  const before = upstream.userTokenRequests;
  const allowed = await (await call('/api/products', sign({ sub: '7' }))).json();
  const denied = await (await call('/api/products', sign({ sub: '9' }))).json();

  assert.equal(allowed.available, true);
  assert.deepEqual({ available: denied.available, error: denied.error }, { available: false, error: 'user_forbidden' });
  assert.equal(upstream.userTokenRequests, before + 1, '9 numaralı kullanıcı için ayrı anahtar alınmalı; 7 saklı anahtarı kullanır');
  assert.equal(upstream.tokenRequests, 0, 'yetkisiz kullanıcıda müşteri anahtarına GEÇİLMEMELİ');
});

test('uygulamayı açma erişimi olmayan kullanıcıya anahtar verilmez; ret kısa süre hatırlanır', async () => {
  const user13 = sign({ sub: '13' });
  const tokenCalls = () => upstream.calls.filter((c) => c === 'POST firma-a.example/api/v1/apps/token').length;

  assert.equal((await (await call('/api/products', user13)).json()).error, 'user_forbidden');
  const before = tokenCalls();
  assert.equal((await (await call('/api/products', user13)).json()).error, 'user_forbidden');
  assert.equal(tokenCalls(), before, 'ret hatırlanırken AsistanX yeniden sorulmamalı');
});

test('kullanıcı anahtarı süresi dolmadan yenilenir', async () => {
  const a = sign();
  await call('/api/products', a);
  const before = upstream.userTokenRequests;

  clock.offset += 58 * 60 * 1000; // 1 saatlik anahtarın son dakikalarına gel
  await call('/api/products', a);
  assert.equal(upstream.userTokenRequests, before, 'süre dolmadıysa yenilenmez');

  clock.offset += 2 * 60 * 1000;
  await call('/api/products', a);
  assert.equal(upstream.userTokenRequests, before + 1, 'son dakikada yenisi alınır');
});

test('oturum bilgisi kullanıcının adını ve yetkilerini taşır', async () => {
  const withUser = sign({ user: { id: 7, name: 'Ayşe Yılmaz', app_manager: true }, user_scopes: ['urunler:read', 5] });
  const me = await (await call('/api/me', withUser)).json();
  assert.equal(me.user_name, 'Ayşe Yılmaz');
  assert.equal(me.app_manager, true);
  assert.deepEqual(me.user_scopes, ['urunler:read']);

  const old = await (await call('/api/me', sign())).json(); // kullanıcı bilgisi göndermeyen eski panel
  assert.deepEqual({ name: old.user_name, manager: old.app_manager, scopes: old.user_scopes }, { name: '', manager: false, scopes: null });
});

test('müşteri anahtarı (arka plan işleri) saklanır ve iptal edilince yenilenir', async () => {
  const installation = db.touchInstallation('firma-a', 'firma-a.example');

  const first = await asistanx.get(installation, 'products', { per_page: 10 });
  assert.equal(first.ok, true);
  assert.equal(upstream.tokenRequests, 1);

  await asistanx.get(installation, 'products');
  assert.equal(upstream.tokenRequests, 1, 'saklı anahtar yeniden kullanılmalı');

  upstream.validToken = 'axat_baska'; // anahtar AsistanX tarafında iptal edildi
  assert.equal((await asistanx.get(installation, 'products')).ok, true);
  assert.equal(upstream.tokenRequests, 2, '401 sonrası yeni anahtar alınmalı');

  const connection = await (await call('/api/connection', sign())).json();
  assert.deepEqual(connection, { connected: true, scopes: ['urunler:read'], offline_access: false });
});

test('izin vermeyen müşteride bağlantı kurulmaz ve ürünler gösterilmez', async () => {
  const b = sign({ tenant: 'firma-b', dest: 'firma-b.example', sub: '3' });
  const res = await (await call('/api/connection', b)).json();
  assert.equal(res.connected, false);
  assert.equal(res.error, 'no_scopes');

  // Kullanıcı anahtarı da verilmez: müşteri uygulamaya hiç izin vermemiş.
  const products = await (await call('/api/products', b)).json();
  assert.deepEqual({ available: products.available, error: products.error }, { available: false, error: 'no_scopes' });
});

test('reddedilen anahtar isteği kısa süre hatırlanır, süre dolunca yeniden sorulur', async () => {
  const b = sign({ tenant: 'firma-b', dest: 'firma-b.example', sub: '3' });
  const tokenCalls = () => upstream.calls.filter((c) => c === 'POST firma-b.example/api/v1/apps/token').length;

  const before = tokenCalls();
  for (let i = 0; i < 5; i += 1) {
    assert.equal((await (await call('/api/connection', b)).json()).error, 'no_scopes');
  }
  assert.equal(tokenCalls(), before, 'süre dolmadan AsistanX yeniden sorulmamalı');

  clock.offset += 61000;
  assert.equal((await (await call('/api/connection', b)).json()).error, 'no_scopes');
  assert.equal(tokenCalls(), before + 1, 'süre dolunca bir kez yeniden sorulmalı');
});

// ---------- Olay bildirimleri (webhook) ----------

function hook(payload, { secret = config.clientSecret, ts = Math.floor(Date.now() / 1000), signature, headers = true } = {}) {
  const raw = JSON.stringify(payload);
  return fetch(base + '/webhooks/asistanx', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(headers
        ? {
            'X-AsistanX-Event': payload.event,
            'X-AsistanX-Delivery': payload.id,
            'X-AsistanX-Timestamp': String(ts),
            'X-AsistanX-Signature': signature ?? signWebhook(secret, String(ts), raw),
          }
        : {}),
    },
    body: raw,
  });
}

const event = (id, name, tenant, data = {}, occurredAt = new Date().toISOString()) =>
  ({ id, event: name, app: 'starter-app', tenant, dest: `${tenant}.example`, occurred_at: occurredAt, data });

test('imza AsistanX ile aynı hesaplanır (sabit örnek)', () => {
  const body = '{"id":"v-1","event":"app.installed","tenant":"firma-ç"}';
  assert.equal(
    signWebhook('axsec_' + 'k'.repeat(48), '1700000000', body),
    'sha256=4fb236390e0e70108faac4be15ae33a4f2cf12e6d8f68f903d41fea43d8e6f43',
  );
});

test('imzasız, yanlış imzalı ve eski bildirimler reddedilir ve işlenmez', async () => {
  const payload = event('w-bad', 'app.installed', 'firma-c');
  const now = Math.floor(Date.now() / 1000);
  const other = signWebhook(config.clientSecret, String(now), JSON.stringify(event('w-x', 'app.installed', 'firma-x')));
  const attempts = {
    'başlık yok': { headers: false },
    'yanlış gizli anahtar': { secret: 'axsec_' + 'z'.repeat(48) },
    'eski zaman damgası': { ts: now - 301 },
    'başka gövdenin imzası': { signature: other },
    'biçimsiz imza': { signature: 'sha256=abc' },
  };
  for (const [name, options] of Object.entries(attempts)) {
    assert.equal((await hook(payload, options)).status, 401, name);
  }
  assert.equal(db.findInstallation('firma-c'), null);
});

test('kurulum bildirimi müşteriyi kaydeder ve "izin yok" hatırasını siler', async () => {
  assert.equal((await hook(event('w-1', 'app.installed', 'firma-c', { scopes: ['urunler:read'] }))).status, 204);
  assert.equal(db.findInstallation('firma-c').tenant_host, 'firma-c.example');

  // firma-b az önce reddedilmişti; kurulum bildirimi gelince beklemeden yeniden sorulur.
  const b = sign({ tenant: 'firma-b', dest: 'firma-b.example', sub: '3' });
  const tokenCalls = () => upstream.calls.filter((c) => c === 'POST firma-b.example/api/v1/apps/token').length;
  await call('/api/connection', b);
  const before = tokenCalls();
  await call('/api/connection', b);
  assert.equal(tokenCalls(), before, 'hatıra sürerken sorulmaz');
  assert.equal((await hook(event('w-2', 'app.installed', 'firma-b'))).status, 204);
  await call('/api/connection', b);
  assert.equal(tokenCalls(), before + 1, 'bildirimden sonra hemen sorulur');
});

test('kaldırma bildirimi API anahtarını siler; aynı bildirim ikinci kez işlenmez', async () => {
  const a = sign();
  await call('/api/connection', a);
  const id = db.findInstallation('firma-a').id;
  assert.notEqual(db.getApiAccess(id), null);

  assert.equal((await hook(event('w-3', 'app.uninstalled', 'firma-a'))).status, 204);
  assert.equal(db.getApiAccess(id), null);
  assert.notEqual(db.findInstallation('firma-a').uninstalled_at, null);

  // Müşteri yeniden açtı: yeni anahtar alındı. Eski bildirimin yeniden gelmesi onu silmemeli.
  await call(`/app?tenant=firma-a.example&token=${a}`);
  await call('/api/connection', a);
  assert.equal(db.findInstallation('firma-a').uninstalled_at, null);
  assert.notEqual(db.getApiAccess(id), null);
  assert.equal((await hook(event('w-3', 'app.uninstalled', 'firma-a'))).status, 204);
  assert.notEqual(db.getApiAccess(id), null);
});

test('geç gelen eski kaldırma bildirimi yeni kurulumun anahtarını silmez', async () => {
  // Müşteri kaldırıp hemen yeniden kurdu; uygulama yeni anahtarı aldı, kaldırma bildirimi sonra ulaştı.
  const id = db.findInstallation('firma-a').id;
  assert.notEqual(db.getApiAccess(id), null);
  const earlier = new Date(Date.now() - 10000).toISOString();
  assert.equal((await hook(event('w-late', 'app.uninstalled', 'firma-a', {}, earlier))).status, 204);
  assert.notEqual(db.getApiAccess(id), null);
  assert.equal(db.findInstallation('firma-a').uninstalled_at, null);
});

test('izin bildirimi saklı izin listesini günceller, anahtarı değiştirmez', async () => {
  const id = db.findInstallation('firma-a').id;
  const before = db.getApiAccess(id);
  assert.equal((await hook(event('w-4', 'app.scopes_updated', 'firma-a', { scopes: ['urunler:read', 'siparisler:read'] }))).status, 204);
  const after = db.getApiAccess(id);
  assert.deepEqual(after.scopes, ['urunler:read', 'siparisler:read']);
  assert.equal(after.tokenEnc, before.tokenEnc);
});

test('bozuk gövde ve tanınmayan olay', async () => {
  assert.equal((await hook({ id: 'w-5', event: 'app.installed', tenant: 'firma-d', dest: 'kötü host/..' })).status, 400);
  assert.equal(db.findInstallation('firma-d'), null);
  assert.equal((await hook(event('w-6', 'order.created', 'firma-a'))).status, 204);
});

test('aynı anda giden istekler tek kullanıcı anahtarını paylaşır; birbirinin anahtarını iptal etmez', async () => {
  // AsistanX gibi davran: yeni kullanıcı anahtarı, o kullanıcının öncekini iptal eder.
  const user = sign({ sub: '21' });
  const before = upstream.userTokenRequests;
  upstream.revokeOld = true;
  try {
    const [products, printers, questions] = await Promise.all([
      call('/api/products', user), call('/api/print/printers', user), call('/api/questions', user),
    ].map((p) => p.then((r) => r.json())));
    assert.equal(products.available, true);
    assert.equal(printers.available, true);
    assert.equal(questions.available, true);
    assert.equal(upstream.userTokenRequests - before, 1, 'üç paralel istek tek anahtar istemeli');

    // Anahtar dışarıdan iptal edilirse (izin değişti): paralel istekler yine TEK yeni anahtar alır.
    upstream.userTokens.clear();
    const again = await Promise.all([call('/api/products', user), call('/api/print/printers', user), call('/api/questions', user)].map((p) => p.then((r) => r.json())));
    assert.deepEqual(again.map((r) => r.available), [true, true, true]);
    assert.equal(upstream.userTokenRequests - before, 2);
  } finally {
    upstream.revokeOld = false;
  }
});

// ---------- Müşteri soruları (okuma ve yazma örneği) ----------

test('cevap bekleyen sorular kullanıcının yetkisiyle okunur; yalnız gereken alanlar tarayıcıya gider', async () => {
  const data = await (await call('/api/questions', sign())).json();
  assert.deepEqual(data, {
    available: true,
    total: 3,
    questions: [{ id: 45, marketplace: 'Trendyol Mağazam', customer_name: 'A*** B***', product_name: 'Deneme ürünü', last_message: 'Kargo kaç günde gelir?', created_at: '2026-01-01T10:00:00+03:00' }],
  });
  assert.ok(upstream.calls.some((c) => c === 'GET firma-a.example/api/v1/mobile/questions'));

  const denied = await (await call('/api/questions', sign({ sub: '9' }))).json();
  assert.deepEqual({ available: denied.available, error: denied.error }, { available: false, error: 'user_forbidden' });

  const noScope = await (await call('/api/questions', sign({ tenant: 'firma-b', dest: 'firma-b.example', sub: '3' }))).json();
  assert.equal(noScope.error, 'no_scopes');
});

test('soru yanıtı kullanıcının anahtarıyla gönderilir; hatalı istek AsistanX\'e hiç gitmez', async () => {
  upstream.questionReplies.length = 0;
  const reply = (id, body, token = sign()) => call(`/api/questions/${id}/reply`, token, { method: 'POST', body: JSON.stringify(body) });

  assert.equal((await reply(45, { message: '   ' })).status, 422);
  assert.equal((await reply(45, {})).status, 422);
  assert.equal((await reply('abc', { message: 'x' })).status, 404);
  assert.equal(upstream.questionReplies.length, 0);

  const ok = await reply(45, { message: '  2 iş günü içinde kargolanır.  ' });
  assert.equal(ok.status, 201);
  assert.deepEqual(await ok.json(), { sent: true, question_id: 45 });
  assert.deepEqual(upstream.questionReplies, [{ method: 'POST', body: { message: '2 iş günü içinde kargolanır.' }, user: '7' }]);

  const missing = await reply(46, { message: 'x' });
  assert.equal(missing.status, 404);
  assert.equal((await missing.json()).error, 'not_found');

  const forbidden = await reply(45, { message: 'x' }, sign({ sub: '9' }));
  assert.equal(forbidden.status, 502);
  assert.equal((await forbidden.json()).error, 'user_forbidden');

  upstream.questionWrite = false;
  try {
    assert.equal((await (await reply(45, { message: 'x' })).json()).error, 'insufficient_scope');
  } finally {
    upstream.questionWrite = true;
  }
  assert.equal(upstream.questionReplies.length, 1, 'reddedilen yanıt yinelenmemeli');
});

// ---------- Yazdırma ----------

test('yazıcılar ekrandaki kullanıcının departmanından okunur', async () => {
  const data = await (await call('/api/print/printers', sign())).json();
  assert.deepEqual(data, {
    available: true,
    department: 'Depo',
    printers: [{ paper: 'A4', label: 'A4', printer: 'HP A4' }, { paper: 'A5', label: 'A5', printer: null }, { paper: 'barcode', label: 'Barkod (etiket)', printer: null }],
  });
  const none = await (await call('/api/print/printers', sign({ sub: '9' }))).json();
  assert.deepEqual({ department: none.department, a4: none.printers[0].printer }, { department: null, a4: null });
});

test('notlar PDF olarak kullanıcının anahtarıyla yazıcıya gönderilir; iş durumu izlenir', async () => {
  const tenant = sign({ tenant: 'firma-a', dest: 'firma-a.example', sub: '7' });
  upstream.printJobs.length = 0;
  db.addNote(db.touchInstallation('firma-a', 'firma-a.example').id, '7', 'Yazdırma denemesi: ğüşiöç (parantez) \\ ters bölü');

  assert.equal((await (await call('/api/print/jobs/4812', tenant)).json()).status, 'waiting');

  const res = await call('/api/print/notes', tenant, { method: 'POST', body: JSON.stringify({ paper: 'A4' }) });
  assert.equal(res.status, 201);
  assert.deepEqual(await res.json(), { job_id: 4812, status: 'waiting', printer: 'HP A4' });

  assert.equal(upstream.printJobs.length, 1);
  const { user, body } = upstream.printJobs[0];
  assert.equal(user, '7');
  assert.deepEqual({ paper: body.paper, copies: body.copies, url: body.url }, { paper: 'A4', copies: 1, url: undefined });

  // Gönderilen içerik gerçekten bir PDF: imza, bitiş işareti ve tutarlı xref.
  const pdf = Buffer.from(body.content_base64, 'base64').toString('latin1');
  assert.ok(pdf.startsWith('%PDF-1.4'));
  assert.ok(pdf.trimEnd().endsWith('%%EOF'));
  assert.match(pdf, /Yazdirma denemesi: gusioc \\\(parantez\\\) \\\\ ters bolu/);
  const xref = Number(pdf.match(/startxref\n(\d+)\n/)[1]);
  assert.equal(pdf.slice(xref, xref + 4), 'xref');
  for (const [, offset] of pdf.slice(xref).matchAll(/^(\d{10}) 00000 n /gm)) {
    assert.match(pdf.slice(Number(offset), Number(offset) + 12), /^\d+ 0 obj/);
  }

  assert.equal((await (await call('/api/print/jobs/4812', tenant)).json()).status, 'printed');
  assert.equal((await call('/api/print/jobs/abc', tenant)).status, 404);
  assert.equal((await call('/api/print/jobs/5', tenant)).status, 404);
});

test('yazdırma: not yoksa ya da yazıcı yoksa AsistanX hatası kullanıcıya iletilir; iş yinelenmez', async () => {
  upstream.printJobs.length = 0;
  const empty = await call('/api/print/notes', sign({ tenant: 'firma-bos', dest: 'firma-a.example', sub: '7' }), { method: 'POST', body: '{}' });
  assert.equal(empty.status, 422);
  assert.equal((await empty.json()).error, 'no_notes');

  const noPrinter = await call('/api/print/notes', sign({ sub: '9' }), { method: 'POST', body: '{}' });
  assert.equal(noPrinter.status, 502);
  const body = await noPrinter.json();
  assert.equal(body.error, 'no_printer');
  assert.match(body.message, /departmana bağlı değil/);
  assert.equal(upstream.printJobs.length, 0);

  // Arka plan (müşteri) anahtarıyla yazdırılamaz: AsistanX user_required döner.
  const installation = db.touchInstallation('firma-a', 'firma-a.example');
  const direct = await asistanx.get(installation, 'printing/printers');
  assert.deepEqual({ ok: direct.ok, error: direct.error }, { ok: false, error: 'user_required' });
});

// ---------- WhatsApp komutları ----------

function wa(command, { tenant = 'firma-a', data = {}, secret = config.clientSecret, ts = Math.floor(Date.now() / 1000), event = 'whatsapp.command' } = {}) {
  const raw = JSON.stringify({
    id: `wa-${Math.random()}`, event, app: 'starter-app', tenant, dest: `${tenant}.example`, occurred_at: new Date().toISOString(),
    data: { command, params: {}, message: 'deneme', sender: { type: 'personnel', user: null }, session_token: null, ...data },
  });
  return fetch(base + '/whatsapp/asistanx', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-AsistanX-Event': event,
      'X-AsistanX-Delivery': 'x',
      'X-AsistanX-Timestamp': String(ts),
      'X-AsistanX-Signature': signWebhook(secret, String(ts), raw),
    },
    body: raw,
  });
}

const asUser = (sub) => ({ sender: { type: 'personnel', user: { id: Number(sub), name: `Kullanıcı ${sub}` } }, session_token: sign({ sub: String(sub) }) });

test('WhatsApp komutu: imzasız, yanlış imzalı, eski ve bozuk istek reddedilir', async () => {
  assert.equal((await wa('not_ozeti', { secret: 'axsec_' + 'z'.repeat(48) })).status, 401);
  assert.equal((await wa('not_ozeti', { ts: Math.floor(Date.now() / 1000) - 3600 })).status, 401);
  assert.equal((await wa('not_ozeti', { event: 'app.installed' })).status, 400);
  assert.equal((await fetch(base + '/whatsapp/asistanx', { method: 'POST', body: '{}' })).status, 401);
});

test('WhatsApp komutu: not özeti yalnız o müşterinin notlarını sayar', async () => {
  const d = sign({ tenant: 'firma-wa', dest: 'firma-wa.example', sub: '4' });
  assert.match((await (await wa('not_ozeti', { tenant: 'firma-wa' })).json()).text, /henüz notunuz yok/);

  await call('/api/notes', d, { method: 'POST', body: JSON.stringify({ body: 'WhatsApp deneme notu' }) });
  const res = await wa('not_ozeti', { tenant: 'firma-wa' });
  assert.equal(res.status, 200);
  const { text } = await res.json();
  assert.match(text, /1 notunuz var/);
  assert.match(text, /WhatsApp deneme notu/);

  assert.doesNotMatch((await (await wa('not_ozeti', { tenant: 'firma-b' })).json()).text, /WhatsApp deneme notu/);
});

test('WhatsApp komutu: ürün sayısı soran kullanıcının yetkisiyle okunur', async () => {
  const before = upstream.tokenRequests;

  assert.equal((await (await wa('urun_sayisi', { data: asUser(7) })).json()).text, 'Toplam 37 ürününüz var.');
  assert.match((await (await wa('urun_sayisi', { data: asUser(9) })).json()).text, /görme yetkiniz yok/);
  assert.match((await (await wa('urun_sayisi')).json()).text, /yalnız panel kullanıcıları/);
  assert.match((await (await wa('urun_sayisi', { tenant: 'firma-b', data: asUser(3) })).json()).text, /izni verilmemiş/);

  assert.equal(upstream.tokenRequests, before, 'WhatsApp isteğinde müşteri anahtarı kullanılmamalı');
});

test('WhatsApp komutu: tanınmayan komut ve nesne tuzakları nazikçe yanıtlanır', async () => {
  for (const name of ['olmayan_komut', 'constructor', '__proto__', 'toString']) {
    const res = await wa(name);
    assert.equal(res.status, 200, name);
    assert.match((await res.json()).text, /tanımıyor/, name);
  }
});

test('WhatsApp çok adımlı konuşma: not ekleme soru sorar, onay ister, sonra kaydeder', async () => {
  const tenant = 'firma-adim';
  const step = async (data) => (await wa('not_ekle', { tenant, data })).json();

  const first = await step({});
  assert.deepEqual(first.expect_reply, { param: 'metin' });
  assert.match(first.text, /Notunuz nedir/);

  const second = await step({ params: { metin: '  Kargo firmasını ara  ' }, state: first.state });
  assert.equal(second.options.question, 'Bu not kaydedilsin mi?');
  assert.deepEqual(second.options.items.map((item) => item.params.onay), ['evet', 'hayir']);
  assert.equal(second.state.metin, 'Kargo firmasını ara');
  assert.equal(second.expect_reply, undefined, 'seçenek ile cevap bekleme birlikte gönderilmez');

  const cancelled = await step({ params: { onay: 'hayir' }, state: second.state });
  assert.match(cancelled.text, /Vazgeçildi/);
  assert.equal(cancelled.state, undefined, 'biten konuşmada durum gönderilmez');
  assert.match((await (await wa('not_ozeti', { tenant })).json()).text, /henüz notunuz yok/);

  const saved = await step({ params: { onay: 'evet' }, state: second.state, ...asUser(7) });
  assert.equal(saved.text, 'Not kaydedildi.');
  assert.match((await (await wa('not_ozeti', { tenant })).json()).text, /Kargo firmasını ara/);

  // Durum kaybolmuşsa (süre dolmuş, başka konuşma) uydurma not kaydedilmez.
  assert.match((await step({ params: { onay: 'evet' } })).text, /bulunamadı/);
});

test('WhatsApp geç yanıt: önce erteleme, sonra müşterinin adresine metin ve dosya', async () => {
  const tenant = 'firma-gec';
  const token = 'axwr_' + 'a'.repeat(48);
  const replyTo = (host) => ({ reply: { url: `https://${host}/api/v1/apps/whatsapp/reply`, token, expires_in: 600 } });

  assert.match((await (await wa('not_dokumu', { tenant, data: replyTo(`${tenant}.example`) })).json()).text, /henüz notunuz yok/);

  const installation = db.touchInstallation(tenant, `${tenant}.example`);
  db.addNote(installation.id, '7', 'Geç yanıt deneme notu');

  // Yanıt adresi müşterinin kendi adresi değilse gizli anahtar gönderilmez.
  upstream.lateReplies.length = 0;
  for (const bad of [replyTo('kotu.example'), { reply: { ...replyTo(`${tenant}.example`).reply, token: 'x' } }, {}]) {
    const out = await (await wa('not_dokumu', { tenant, data: bad })).json();
    assert.equal(out.defer, undefined);
    assert.match(out.text, /gönderilemiyor/);
  }
  await app.locals.whatsapp.idle();
  assert.equal(upstream.lateReplies.length, 0);

  const first = await (await wa('not_dokumu', { tenant, data: replyTo(`${tenant}.example`) })).json();
  assert.equal(first.defer, true);
  assert.match(first.text, /hazırlıyorum/);

  await app.locals.whatsapp.idle();
  assert.equal(upstream.lateReplies.length, 1);
  const { host, body } = upstream.lateReplies[0];
  assert.equal(host, `${tenant}.example`);
  assert.equal(body.reply_token, token);
  assert.equal(body.client_id, config.clientId);
  assert.match(body.text, /1 not/);
  assert.equal(body.defer, undefined);
  assert.equal(body.media.length, 1);

  // Dosya adresi kısa ömürlü ve tahmin edilemez; oturumsuz indirilebilir.
  const fileUrl = new URL(body.media[0].url);
  assert.equal(fileUrl.protocol, 'https:');
  assert.match(fileUrl.pathname, /^\/whatsapp\/files\/[0-9a-f]{48}\/notlar\.txt$/);
  const file = await fetch(base + fileUrl.pathname);
  assert.equal(file.status, 200);
  assert.match(await file.text(), /Geç yanıt deneme notu/);
  assert.equal((await fetch(base + '/whatsapp/files/' + 'b'.repeat(48) + '/notlar.txt')).status, 404);
});

// ---------- Arka planda erişim ve tam ekran ----------

test('bağlantı ucu arka planda erişim iznini bildirir', async () => {
  const installation = db.touchInstallation('firma-a', 'firma-a.example');
  asistanx.forget(installation.id, { dropToken: true });
  upstream.tenantScopes = ['urunler:read', 'arkaplan:read'];
  try {
    const connection = await (await call('/api/connection', sign())).json();
    assert.deepEqual(connection, { connected: true, scopes: ['urunler:read', 'arkaplan:read'], offline_access: true });
  } finally {
    upstream.tenantScopes = ['urunler:read'];
    asistanx.forget(installation.id, { dropToken: true });
  }
});

test('giriş sayfasında panele dönüş düğmesi ve tam ekran bilgisi yeri vardır', async () => {
  const html = await (await fetch(`${base}/app?tenant=firma-a.example&token=${sign()}`)).text();
  assert.match(html, /data-close/);
  assert.match(html, /data-fullscreen-info/);
  assert.match(html, /data-fact="offline_access"/);
});

test('adres eşitleme: sayfada bölüm bağlantıları ve bölüm işaretleri vardır; istemci asistanx:navigate yollar ve path okur', async () => {
  const html = await (await fetch(`${base}/app?tenant=firma-a.example&token=${sign()}&path=%2Fnotlar`)).text();
  for (const s of ['oturum', 'urunler', 'sorular', 'notlar']) {
    assert.match(html, new RegExp(`data-goto="${s}"`));
    assert.match(html, new RegExp(`data-section="${s}"`));
  }
  const js = await (await fetch(`${base}/static/app.js`)).text();
  assert.match(js, /asistanx:navigate/);
  assert.match(js, /params\.get\('path'\)/);
});

test('e-posta bildirimi: sendMail müşteri anahtarıyla uygulama ucuna gider; 401 sonrası aynı idempotency anahtarıyla bir kez yinelenir', async () => {
  const installation = db.touchInstallation('firma-a', 'firma-a.example');
  asistanx.forget(installation.id, { dropToken: true });
  upstream.tenantScopes = ['eposta:read'];
  upstream.mails.length = 0;
  try {
    const message = { to_user_ids: [7, 13], subject: 'Rapor hazır', text: 'Merhaba', idempotency_key: 'rapor-1' };
    const first = await asistanx.sendMail(installation, message);
    assert.equal(first.ok, true);
    assert.deepEqual(first.data, { id: 'mail-1', accepted: [7], rejected: [{ user_id: 13, reason: 'no_app_access' }] });
    assert.ok(upstream.calls.includes('POST firma-a.example/api/v1/apps/mail'), 'uç api_base dışında: /api/v1/apps/mail');

    upstream.validToken = 'axat_iptal_edildi'; // anahtar AsistanX'te iptal edildi → 401 → yeni anahtar → aynı gövde
    const before = upstream.tokenRequests;
    const again = await asistanx.sendMail(installation, message);
    assert.equal(upstream.tokenRequests, before + 1);
    assert.equal(again.ok, true);
    assert.equal(again.data.duplicate, true, 'aynı idempotency anahtarı ikinci e-postayı göndermez');
    assert.equal(upstream.mails.length, 1);
  } finally {
    upstream.tenantScopes = ['urunler:read'];
    asistanx.forget(installation.id, { dropToken: true });
  }
});

test('e-posta bildirimi: izin yoksa insufficient_scope; geçerli alıcı yoksa rejected nedenleriyle döner', async () => {
  const installation = db.touchInstallation('firma-a', 'firma-a.example');
  asistanx.forget(installation.id, { dropToken: true });
  upstream.mails.length = 0;
  try {
    const denied = await asistanx.sendMail(installation, { to_user_ids: [7], subject: 'x', text: 'y' });
    assert.deepEqual({ ok: denied.ok, status: denied.status, error: denied.error }, { ok: false, status: 403, error: 'insufficient_scope' });

    upstream.tenantScopes = ['eposta:read'];
    asistanx.forget(installation.id, { dropToken: true });
    const none = await asistanx.sendMail(installation, { to_user_ids: [13], subject: 'x', text: 'y' });
    assert.equal(none.ok, false);
    assert.equal(none.error, 'no_valid_recipients');
    assert.deepEqual(none.rejected, [{ user_id: 13, reason: 'no_app_access' }]);
  } finally {
    upstream.tenantScopes = ['urunler:read'];
    asistanx.forget(installation.id, { dropToken: true });
  }
});

test('e-posta bildirimi (kendime): alıcı oturumdaki kullanıcıdır, tarayıcıdan alıcı alınmaz; düğme uygulamanın adresine gider', async () => {
  const installation = db.touchInstallation('firma-a', 'firma-a.example');
  asistanx.forget(installation.id, { dropToken: true });
  upstream.tenantScopes = ['eposta:read'];
  upstream.mails.length = 0;
  try {
    const res = await call('/api/mail/self', sign(), {
      method: 'POST',
      body: JSON.stringify({ subject: 'Deneme', text: 'Merhaba', to_user_ids: [99, 100], to: 'dis@example.com' }),
    });
    assert.equal(res.status, 202);
    const data = await res.json();
    assert.deepEqual(data.accepted, [7]);
    assert.doesNotMatch(JSON.stringify(data), /axat_|axut_|axsec_/);

    assert.equal(upstream.mails.length, 1);
    const sent = upstream.mails[0];
    assert.equal(sent.host, 'firma-a.example');
    assert.deepEqual(sent.body.to_user_ids, [7], 'yalnız oturumdaki kullanıcı (sub)');
    assert.equal(sent.body.to, undefined);
    assert.equal(sent.body.subject, 'Deneme');
    assert.match(sent.body.action.url, /^https:\/\/127\.0\.0\.1:\d+\/$/);
    assert.match(sent.body.idempotency_key, /^starter-self-[0-9a-f-]{36}$/);

    // Uygulamayı açamayan kullanıcı: AsistanX alıcıyı reddeder, neden tarayıcıya iletilir.
    const denied = await call('/api/mail/self', sign({ sub: '13' }), { method: 'POST', body: JSON.stringify({ subject: 'x', text: 'y' }) });
    assert.equal(denied.status, 422);
    assert.deepEqual(await denied.json(), { error: 'no_valid_recipients', message: 'Alıcıların hiçbirine e-posta gönderilemez.', rejected: [{ user_id: 13, reason: 'no_app_access' }] });

    // Boş konu ve uzun ileti AsistanX'e hiç gitmez.
    for (const body of [{ subject: '', text: 'y' }, { subject: 'x', text: 'y'.repeat(2001) }, { subject: 'x'.repeat(151), text: 'y' }]) {
      const bad = await call('/api/mail/self', sign(), { method: 'POST', body: JSON.stringify(body) });
      assert.equal(bad.status, 422);
    }
    assert.equal(upstream.mails.length, 2);
  } finally {
    upstream.tenantScopes = ['urunler:read'];
    asistanx.forget(installation.id, { dropToken: true });
  }
});

test('e-posta bildirimi: izin verilmemişse kendime gönder hata kodunu iletir', async () => {
  const installation = db.touchInstallation('firma-a', 'firma-a.example');
  asistanx.forget(installation.id, { dropToken: true });
  const res = await call('/api/mail/self', sign(), { method: 'POST', body: JSON.stringify({ subject: 'x', text: 'y' }) });
  assert.equal(res.status, 502);
  assert.equal((await res.json()).error, 'insufficient_scope');
  asistanx.forget(installation.id, { dropToken: true });
});

test('e-posta bildirimi: sayfada örnek kart ve bölüm bağlantısı vardır', async () => {
  const html = await (await fetch(`${base}/app?tenant=firma-a.example&token=${sign()}`)).text();
  assert.match(html, /data-section="eposta"/);
  assert.match(html, /data-goto="eposta"/);
  assert.match(html, /E-posta bildirimi gönder \(kendime\)/);
  const js = await (await fetch(`${base}/static/app.js`)).text();
  assert.match(js, /\/api\/mail\/self/);
});
