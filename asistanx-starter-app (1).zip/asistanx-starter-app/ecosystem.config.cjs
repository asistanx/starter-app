// PM2 ayarı: `pm2 start ecosystem.config.cjs` ile başlatılır.
module.exports = {
  apps: [
    {
      name: 'asistanx-starter-app',
      script: 'src/server.js',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      max_memory_restart: '200M',
      env: { NODE_ENV: 'production' },
    },
  ],
};
